qbd_bind <- function(x) {
  x <- Filter(function(z) !is.null(z) && nrow(z) > 0L, x)
  if (!length(x)) return(data.frame())
  ans <- do.call(rbind, x); rownames(ans) <- NULL; ans
}
qbd_tag <- function(x, case) {
  for (key in c("case_id", "model", "n", "phi")) x[[key]] <- case[[key]]
  x
}
qbd_interval <- function(count, total) {
  z <- qnorm(.975); p <- count / total
  center <- (p + z^2 / (2 * total)) / (1 + z^2 / total)
  half <- z * sqrt(p * (1 - p) / total + z^2 / (4 * total^2)) / (1 + z^2 / total)
  cbind(MC_lower = pmax(0, center - half), MC_upper = pmin(1, center + half))
}

qbd_summarize <- function(directory) {
  meta <- readRDS(file.path(directory, "manifest.rds"))
  cfg <- meta$config; design <- meta$design
  rejection <- covariance <- full_covariance <- correction <- paired <- list()
  errors <- warnings <- ties <- runtime <- list()
  completion <- design; completion$R_completed <- 0L; completion$R_failed <- 0L
  for (cc in seq_len(nrow(design))) {
    case <- as.list(design[cc,,drop = FALSE]); opt <- meta$options[[case$model]]
    ctx <- qbp_context(case$n, cfg$H, .5); d <- nrow(ctx$lags); K <- nrow(opt)
    ref <- which(opt$correction == "estimated" & opt$alignment == "base" &
                   !is.na(opt$bw_factor) & opt$bw_factor == 1 & opt$block_factor == 1)
    if (length(ref) != 1L) ref <- integer()
    count <- 0L; failed <- 0L; elapsed <- 0
    mean_k <- numeric(d); M2 <- matrix(0, d, d)
    sum_omega <- array(0, c(d,d,K)); sum_p <- sum_stat <- sum_reject <- matrix(0, K, 2L)
    sum_cover <- matrix(0, K, d); diff_sum <- diff_square <- matrix(0, K, 2L)
    sum_m <- sum_m2 <- array(0, c(d,3L,length(cfg$BW_FACTORS)))
    seen <- integer()
    files <- list.files(file.path(directory, "checkpoints", case$case_id), pattern = "\\.rds$", full.names = TRUE)
    for (path in files) {
      chunk <- readRDS(path)
      if (!identical(chunk$fingerprint, meta$fingerprint)) stop("Checkpoint mismatch: ", path)
      for (r in chunk$results) {
        if (!identical(r$case_id, case$case_id) || r$replication %in% seen ||
            r$replication < 1L || r$replication > case$replications)
          stop("Duplicate or invalid record in ", path)
        seen <- c(seen, r$replication); elapsed <- elapsed + r$elapsed_seconds
        if (length(r$warnings)) warnings[[length(warnings)+1L]] <-
          qbd_tag(data.frame(replication=r$replication, warning=r$warnings), case)
        if (r$status != "ok") {
          failed <- failed + 1L
          errors[[length(errors)+1L]] <- qbd_tag(data.frame(replication=r$replication, error=r$error),case)
          next
        }
        count <- count + 1L
        delta <- r$kappa - mean_k; mean_k <- mean_k + delta / count
        M2 <- M2 + tcrossprod(delta, r$kappa - mean_k)
        sum_omega <- sum_omega + r$omega
        sum_p <- sum_p + r$p_values; sum_stat <- sum_stat + r$statistics
        rejected <- r$p_values <= cfg$ALPHA; sum_reject <- sum_reject + rejected
        sum_cover <- sum_cover + r$covered
        if (length(ref)) {
          difference <- sweep(rejected * 1, 2L, rejected[ref,], "-")
          diff_sum <- diff_sum + difference; diff_square <- diff_square + difference^2
        }
        for (b in seq_along(cfg$BW_FACTORS)) {
          sum_m[,,b] <- sum_m[,,b] + r$mhat[[b]]
          sum_m2[,,b] <- sum_m2[,,b] + r$mhat[[b]]^2
        }
        if (r$numerical_ties$groups > 0L) ties[[length(ties)+1L]] <-
          qbd_tag(cbind(data.frame(replication=r$replication), as.data.frame(r$numerical_ties)),case)
      }
    }
    completion$R_completed[cc] <- count; completion$R_failed[cc] <- failed
    runtime[[cc]] <- qbd_tag(data.frame(R_completed=count, R_failed=failed,
      total_worker_seconds=elapsed, mean_seconds=if (length(seen)) elapsed/length(seen) else NA_real_),case)
    if (!count) next
    empirical <- if (count > 1L) (M2+t(M2))/2/(count-1L) else matrix(NA_real_,d,d)
    estimates <- sum_omega / count / case$n
    for (i in seq_len(K)) {
      prob <- sum_reject[i,] / count
      rej <- cbind(opt[rep(i,2L),,drop=FALSE],
        data.frame(method=c("energy","maximum"), R_completed=count,
          rejection_rate=prob, MCSE=sqrt(prob*(1-prob)/count),
          qbd_interval(sum_reject[i,],count), mean_p_value=sum_p[i,]/count,
          mean_statistic=sum_stat[i,]/count))
      length_i <- ceiling(opt$block_factor[i] * ceiling(log(case$n)))
      rej$block_length <- length_i; rej$number_of_blocks <- ctx$N %/% length_i
      rejection[[length(rejection)+1L]] <- qbd_tag(rej,case)
      ev <- diag(empirical); av <- diag(estimates[,,i]); coverage <- sum_cover[i,]/count
      cov <- cbind(opt[rep(i,d),,drop=FALSE],data.frame(h=ctx$lags[,1L], k=ctx$lags[,2L],
        R_completed=count, mean_estimate=mean_k, empirical_variance=ev,
        mean_estimated_variance=av, variance_ratio=ifelse(ev>0,av/ev,NA_real_),
        coverage=coverage, coverage_MCSE=sqrt(coverage*(1-coverage)/count),
        block_length=length_i, number_of_blocks=ctx$N %/% length_i))
      covariance[[length(covariance)+1L]] <- qbd_tag(cov,case)
      ij <- expand.grid(a=seq_len(d),b=seq_len(d))
      mat <- cbind(opt[rep(i,nrow(ij)),,drop=FALSE],
        data.frame(h1=ctx$lags[ij$a,1L],k1=ctx$lags[ij$a,2L],
          h2=ctx$lags[ij$b,1L],k2=ctx$lags[ij$b,2L],R_completed=count,
          empirical_covariance=as.vector(empirical), mean_estimated_covariance=as.vector(estimates[,,i]),
          covariance_error=as.vector(estimates[,,i]-empirical)))
      full_covariance[[length(full_covariance)+1L]] <- qbd_tag(mat,case)
      if (length(ref)) {
        delta <- diff_sum[i,]/count
        se <- if (count>1L) sqrt(pmax(0,diff_square[i,]-count*delta^2)/(count*(count-1L))) else rep(NA_real_,2L)
        row <- cbind(opt[rep(i,2L),,drop=FALSE],data.frame(method=c("energy","maximum"),
          reference_option_id=opt$option_id[ref],R_completed=count,difference=delta,paired_MCSE=se,
          MC_lower=delta-qnorm(.975)*se,MC_upper=delta+qnorm(.975)*se))
        paired[[length(paired)+1L]] <- qbd_tag(row,case)
      }
    }
    truth <- if (case$model=="normal") qbd_oracle_m(case$phi,ctx$lags) else matrix(NA_real_,d,3L)
    ij <- expand.grid(a=seq_len(d),position=1:3)
    for (b in seq_along(cfg$BW_FACTORS)) {
      m <- sum_m[,,b]/count
      se <- if (count>1L) sqrt(pmax(0,sum_m2[,,b]-count*m^2)/(count*(count-1L))) else matrix(NA_real_,d,3L)
      rmse <- sqrt(pmax(0,sum_m2[,,b]/count-2*truth*m+truth^2))
      row <- data.frame(h=ctx$lags[ij$a,1L],k=ctx$lags[ij$a,2L],position=ij$position,
        bw_factor=cfg$BW_FACTORS[b],bandwidth=cfg$BW_FACTORS[b]*case$n^(-1/6),R_completed=count,
        true_m=as.vector(truth),mean_mhat=as.vector(m),bias=as.vector(m-truth),
        RMSE=as.vector(rmse),mean_MCSE=as.vector(se))
      correction[[length(correction)+1L]] <- qbd_tag(row,case)
    }
  }
  completion$complete <- completion$R_completed == completion$replications
  summaries <- list(rejection=qbd_bind(rejection), covariance=qbd_bind(covariance),
    covariance_full=qbd_bind(full_covariance), marginal_correction=qbd_bind(correction),
    paired_rejection_difference=qbd_bind(paired), completion=completion,
    errors=qbd_bind(errors), warnings=qbd_bind(warnings), numerical_ties=qbd_bind(ties), runtime=qbd_bind(runtime))
  for (name in names(summaries)) write.csv(summaries[[name]],file.path(directory,paste0(name,".csv")),row.names=FALSE,na="")
  config <- cfg; options_by_model <- meta$options
  save(summaries,config,design,options_by_model,file=file.path(directory,"supplement_results.RData"),compress=TRUE)
  cat(sprintf("Supplement summaries: %d successes, %d errors, %d warning records.\n",
              sum(completion$R_completed),nrow(summaries$errors),nrow(summaries$warnings)))
  invisible(summaries)
}

qbd_load_case <- function(directory, case_id) {
  meta <- readRDS(file.path(directory,"manifest.rds"))
  if (!case_id %in% meta$design$case_id) stop("Unknown case_id.")
  paths <- list.files(file.path(directory,"checkpoints",case_id),pattern="\\.rds$",full.names=TRUE)
  out <- list()
  for (path in paths) {
    x <- readRDS(path)
    if (!identical(x$fingerprint,meta$fingerprint)) stop("Checkpoint mismatch.")
    out <- c(out,x$results)
  }
  out
}

qbd_plot <- function(directory) {
  path <- file.path(directory,"rejection.csv")
  if (!file.exists(path) || file.info(path)$size < 10) return(invisible(NULL))
  tab <- read.csv(path,stringsAsFactors=FALSE)
  if (!nrow(tab)) return(invisible(NULL))
  out <- file.path(directory,"figures");dir.create(out,showWarnings=FALSE)
  meta <- readRDS(file.path(directory,"manifest.rds"));cfg <- meta$config
  for (model in unique(tab$model)) for (phi in unique(tab$phi)) for (method in c("energy","maximum")) {
    s <- tab[tab$model==model & tab$phi==phi & tab$method==method & tab$correction=="estimated",]
    if (!nrow(s)) next
    pdf(file.path(out,sprintf("size_%s_phi%s_%s.pdf",model,phi,method)),width=10,height=8)
    par(mfrow=c(length(cfg$BW_FACTORS),length(cfg$ALIGNMENTS)),mar=c(3,3,2,1),oma=c(1,1,3,0))
    colors <- c("#0072B2","#D55E00","#009E73","#CC79A7","#E69F00")
    for (bw in cfg$BW_FACTORS) for (align in cfg$ALIGNMENTS) {
      a <- s[s$bw_factor==bw & s$alignment==align,,drop=FALSE]
      upper <- max(.10,s$rejection_rate+2*s$MCSE)
      xr <- range(tab$n);if (diff(xr)==0) xr <- xr*c(.9,1.1)
      plot(NA,xlim=xr,ylim=c(0,upper),log="x",xaxt="n",xlab="n",ylab="Rejection proportion",
           main=paste(align,"correction, bandwidth x",bw))
      axis(1,at=sort(unique(tab$n)),labels=sort(unique(tab$n)))
      abline(h=cfg$ALPHA,lty=2,col="gray40")
      for (j in seq_along(cfg$BLOCK_FACTORS)) {
        b <- a[a$block_factor==cfg$BLOCK_FACTORS[j],];b <- b[order(b$n),]
        color <- colors[(j-1L) %% length(colors)+1L]
        lines(b$n,b$rejection_rate,type="b",pch=j,col=color)
        arrows(b$n,b$MC_lower,b$n,b$MC_upper,angle=90,code=3,length=.025,col=color)
      }
      legend("topright",legend=paste("Block x",cfg$BLOCK_FACTORS),
             col=colors[(seq_along(cfg$BLOCK_FACTORS)-1L) %% length(colors)+1L],
             pch=seq_along(cfg$BLOCK_FACTORS),lty=1,bty="n",cex=.65)
    }
    mtext(sprintf("%s AR(1), phi=%s, %s test",model,phi,method),outer=TRUE,line=1,font=2)
    dev.off()
  }
  invisible(out)
}
