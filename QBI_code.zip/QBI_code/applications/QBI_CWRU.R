qa_script_dir <- function() {
  for(fr in rev(sys.frames())) if(!is.null(fr$ofile))
    return(dirname(normalizePath(fr$ofile,winslash="/",mustWork=FALSE)))
  z<-grep("^--file=",commandArgs(FALSE),value=TRUE)
  if(length(z)) return(dirname(normalizePath(sub("^--file=","",z[1]),winslash="/",mustWork=FALSE)))
  getwd()
}
QA_SCRIPT_DIR <- qa_script_dir()

CONFIG <- list(
  DATASET = "CWRU",
  INPUT_DIR = file.path(QA_SCRIPT_DIR, "CWRU_data"),
  OUTPUT_DIR = file.path(QA_SCRIPT_DIR, "CWRU_supplement_results"),
  WORKERS = 8L,
  SEED = 20260925L,
  B_PRIMARY = 49999L,
  B_SENSITIVITY = 49999L,
  MULTIPLIER_CHUNK = 256L,
  ALPHA = .05,
  LEVELS = c(.25,.5,.75),
  BW_FACTOR = 1,
  ALIGNMENTS = c("lagged","base"),
  PRIMARY_ALIGNMENT = "lagged",
  MIN_BLOCKS = 30L,
  MIN_N = 1024L,
  TIES_POLICY = "descriptive",
  MAP_H = 24L,
  MAP_H_VALUES = c(12L,24L,48L),
  FREQ_GRID = 49L,
  PLOT_TUPLES = rbind(c(.25,.25,.25),c(.5,.5,.5),c(.75,.75,.75),
    c(.25,.5,.75),c(.75,.5,.25),c(.25,.75,.5)),
  MAKE_PLOTS = TRUE,
  RUN_EXTENDED_LAGS = TRUE,
  LAG_POINTS = c(1L,2L,4L,8L,16L),
  RUN_CALIBRATION = TRUE,
  CALIBRATION_REPS = 500L,
  CALIBRATION_B = 999L,
  CALIBRATION_N = c(4096L,8192L),
  STAGES = c("primary","short_window","filter_0900Hz","filter_1350Hz"),
  LOADS = 0:3,
  CONDITIONS = c("Normal","IR007","OR007_6oclock"),
  RAW_FS = 48000,
  DECIMATE_FACTOR = 16L,
  FIR_HALF_WIDTH_PER_FACTOR = 12L,
  FIR_CUTOFF_FRACTION = .8,
  BLOCK_LENGTHS = c(128L,256L),
  PRIMARY_BLOCK = 128L
)

QA_VERSION <- "QBP-supplement-2.0.0"

qa_hash <- function(x) {
  f <- tempfile(); on.exit(unlink(f)); saveRDS(x, f, version = 2)
  unname(tools::md5sum(f))
}
qa_save <- function(x, f) {
  dir.create(dirname(f), recursive = TRUE, showWarnings = FALSE)
  tmp <- paste0(f, ".", Sys.getpid(), ".tmp")
  saveRDS(x, tmp, compress = TRUE)
  if (file.exists(f)) unlink(f)
  if (!file.rename(tmp, f)) {
    if(!file.copy(tmp,f,overwrite=TRUE) || !identical(unname(tools::md5sum(tmp)),unname(tools::md5sum(f))))
      stop("Cannot commit checkpoint; completed temporary file retained at ",tmp)
    unlink(tmp)
  }
}
qa_csv <- function(x, f) {
  if (is.null(x)) x <- data.frame()
  utils::write.csv(x, f, row.names = FALSE, na = "", fileEncoding = "UTF-8")
}
qa_bind <- function(xs) {
  xs <- Filter(function(x) !is.null(x) && nrow(x) > 0L, xs)
  if (!length(xs)) return(data.frame())
  cols <- unique(unlist(lapply(xs, names)))
  xs <- lapply(xs, function(x) { for (v in setdiff(cols,names(x))) x[[v]] <- NA; x[,cols,drop=FALSE] })
  do.call(rbind, xs)
}
qa_grid <- function(levels) {
  q <- length(levels)
  a <- as.matrix(expand.grid(a=seq_len(q),b=seq_len(q),c=seq_len(q)))
  b <- as.matrix(expand.grid(a=seq_len(q),b=seq_len(q)))
  list(triples=a,pairs=b,tau=matrix(levels[a],nrow(a),3),
       pair_tau=matrix(levels[b],nrow(b),2),keys=apply(a,1,paste,collapse=":"))
}
qa_rank <- function(y, levels, policy) {
  tied <- anyDuplicated(y) > 0L
  if (tied && policy == "stop") stop("Ties found; no random tie breaking is performed.")
  v <- rank(y,ties.method="max") / length(y)
  U <- outer(v,levels,"<=") * 1

  center <- if (tied) colMeans(U) else levels
  U <- sweep(U,2,center,"-")
  list(v=v,U=U,center=center,tied=tied)
}
qa_block_sum <- function(score, ell) {
  N <- nrow(score); q <- N %/% ell
  score <- sweep(score,2,colMeans(score),"-")
  rowsum(score[seq_len(q*ell),,drop=FALSE], rep(seq_len(q),each=ell),reorder=FALSE)
}
qa_standardize <- function(y) {
  z <- y / max(abs(y)); z <- z - mean(z)
  s <- sqrt(mean(z*z))
  if (!is.finite(s) || s <= 0) stop("Constant/invalid signal.")
  z / s
}

qa_fit <- function(y, cfg) {
  n <- length(y); points <- sort(unique(as.integer(cfg$LAG_POINTS)))
  lag <- t(combn(points,2L)); H <- max(points); N <- n-H; tt <- seq_len(N)
  g <- qa_grid(cfg$LEVELS); nt <- nrow(g$triples); np <- nrow(g$pairs)
  rk <- qa_rank(y,cfg$LEVELS,cfg$TIES_POLICY); U <- rk$U; z <- qa_standardize(y)
  bw <- cfg$BW_FACTOR*n^(-1/6)
  kw <- pmax(1-abs(outer(rk$v,cfg$LEVELS,"-"))/bw,0)
  ells <- sort(unique(as.integer(cfg$BLOCK_LENGTHS)))
  configs <- expand.grid(alignment=cfg$ALIGNMENTS,block_length=ells,stringsAsFactors=FALSE)
  configs$n_blocks <- N %/% configs$block_length
  if (any(configs$n_blocks < 2L)) stop("Fewer than two covariance blocks.")
  d <- nrow(lag)*nt + length(points)*np + nrow(lag)
  S <- lapply(configs$n_blocks,function(q) matrix(0,q,d))
  index <- vector("list",nrow(lag)+length(points)+nrow(lag))
  kappa <- numeric(d); mhat <- matrix(NA_real_,d,3); pos <- 0L; ii <- 0L
  put <- function(raw, correction_base, correction_lagged, meta, mh) {
    p <- ncol(raw); ix <- pos+seq_len(p); pos <<- pos+p; ii <<- ii+1L
    kappa[ix] <<- colMeans(raw); index[[ii]] <<- meta; mhat[ix,] <<- mh
    for (align in unique(configs$alignment)) {
      score <- raw - if (align == "base") correction_base else correction_lagged
      for (v in which(configs$alignment == align))
        S[[v]][,ix] <<- qa_block_sum(score,configs$block_length[v])
    }
  }
  div <- function(a,b) {if (any(b<=0)) stop("Empty conditional-moment kernel window"); a/b}
  for (j in seq_len(nrow(lag))) {
    h <- lag[j,1]; k <- lag[j,2]; a <- g$triples[,1]; b <- g$triples[,2]; c <- g$triples[,3]
    u1 <- U[tt,a,drop=FALSE]; u2 <- U[tt+h,b,drop=FALSE]; u3 <- U[tt+k,c,drop=FALSE]
    w1 <- kw[tt,a,drop=FALSE]; w2 <- kw[tt+h,b,drop=FALSE]; w3 <- kw[tt+k,c,drop=FALSE]
    m <- cbind(div(colSums(w1*u2*u3),colSums(w1)),
               div(colSums(w2*u1*u3),colSums(w2)),div(colSums(w3*u1*u2),colSums(w3)))
    base <- sweep(u1,2,m[,1],"*")+sweep(U[tt,b,drop=FALSE],2,m[,2],"*")+
      sweep(U[tt,c,drop=FALSE],2,m[,3],"*")
    aligned <- sweep(u1,2,m[,1],"*")+sweep(u2,2,m[,2],"*")+sweep(u3,2,m[,3],"*")
    meta <- data.frame(type="rank3",h=h,k=k,tau1=g$tau[,1],tau2=g$tau[,2],tau3=g$tau[,3],
                       reference_variance=apply(g$tau*(1-g$tau),1,prod))
    put(u1*u2*u3,base,aligned,meta,m)
  }
  for (h in points) {
    a <- g$pairs[,1]; b <- g$pairs[,2]
    u1 <- U[tt,a,drop=FALSE]; u2 <- U[tt+h,b,drop=FALSE]
    w1 <- kw[tt,a,drop=FALSE]; w2 <- kw[tt+h,b,drop=FALSE]
    m <- cbind(div(colSums(w1*u2),colSums(w1)),div(colSums(w2*u1),colSums(w2)),NA_real_)
    base <- sweep(u1,2,m[,1],"*")+sweep(U[tt,b,drop=FALSE],2,m[,2],"*")
    aligned <- sweep(u1,2,m[,1],"*")+sweep(u2,2,m[,2],"*")
    meta <- data.frame(type="rank2",h=h,k=NA_integer_,tau1=g$pair_tau[,1],tau2=g$pair_tau[,2],
                       tau3=NA_real_,reference_variance=apply(g$pair_tau*(1-g$pair_tau),1,prod))
    put(u1*u2,base,aligned,meta,m)
  }
  for (j in seq_len(nrow(lag))) {
    h <- lag[j,1]; k <- lag[j,2]; zz <- cbind(z[tt],z[tt+h],z[tt+k])
    raw <- zz[,1]*zz[,2]*zz[,3]; mu <- mean(raw)
    m <- c(mean(zz[,2]*zz[,3]),mean(zz[,1]*zz[,3]),mean(zz[,1]*zz[,2]))
    base <- sum(m)*z[tt]+1.5*mu*(z[tt]^2-1)
    aligned <- as.numeric(zz %*% m)+0.5*mu*rowSums(zz^2-1)
    meta <- data.frame(type="ordinary3",h=h,k=k,tau1=NA_real_,tau2=NA_real_,tau3=NA_real_,
                       reference_variance=1)
    put(matrix(raw,ncol=1),matrix(base,ncol=1),matrix(aligned,ncol=1),meta,matrix(m,nrow=1))
  }
  index <- do.call(rbind,index); index$estimate <- kappa
  index$m1 <- mhat[,1]; index$m2 <- mhat[,2]; index$m3 <- mhat[,3]
  list(index=index,S=S,configs=configs,n=n,N=N,bandwidth=bw,tied=rk$tied,center=rk$center)
}

qa_groups <- function(idx) {
  r <- which(idx$type=="rank3")
  list(QBP_median=r[idx$tau1[r]==.5 & idx$tau2[r]==.5 & idx$tau3[r]==.5],
       QBP_diagonal=r[idx$tau1[r]==idx$tau2[r] & idx$tau2[r]==idx$tau3[r]],
       QBP_mixed_all=r,
       QBP_ordered6=r[idx$tau1[r]!=idx$tau2[r] & idx$tau1[r]!=idx$tau3[r] & idx$tau2[r]!=idx$tau3[r]],
       Pairwise_rank=which(idx$type=="rank2"),Ordinary_bispectrum=which(idx$type=="ordinary3"))
}

qa_coefficients <- function(kappa,lags,grid,tuple,weights) {
  a <- match(tuple,grid$levels)
  perms <- rbind(a[c(1,2,3)],a[c(1,3,2)],a[c(2,1,3)],a[c(3,1,2)],a[c(2,3,1)],a[c(3,2,1)])
  cols <- match(apply(perms,1,paste,collapse=":"),grid$keys)
  do.call(rbind,lapply(seq_len(nrow(lags)),function(i) {
    h <- lags[i,1]; k <- lags[i,2]
    data.frame(h=c(h,k,-h,k-h,-k,h-k),k=c(k,h,k-h,-h,h-k,-k),value=weights[i]*kappa[i,cols])
  }))
}
qa_surface <- function(co,freq,fs) {
  A <- exp(-2i*pi*outer(co$h,freq)/fs); B <- exp(-2i*pi*outer(co$k,freq)/fs)

  t(A) %*% (co$value*B) / fs^2
}
qa_spectra <- function(y,fs,cfg) {
  n <- length(y); H <- cfg$MAP_H; M <- H+1; lag <- t(combn(seq_len(H),2))
  g <- qa_grid(cfg$LEVELS); g$levels <- cfg$LEVELS
  rk <- qa_rank(y,cfg$LEVELS,cfg$TIES_POLICY); q <- length(cfg$LEVELS); K <- q+1L
  cat <- rowSums(outer(rk$v,cfg$LEVELS,">"))
  cc <- as.matrix(expand.grid(a=0:q,b=0:q,c=0:q))
  uc <- sweep(outer(0:q,seq_len(q)-1L,"<="),2,rk$center,"-")
  w3 <- uc[cc[,1]+1,g$triples[,1],drop=FALSE]*uc[cc[,2]+1,g$triples[,2],drop=FALSE]*
    uc[cc[,3]+1,g$triples[,3],drop=FALSE]
  km <- matrix(0,nrow(lag),nrow(g$triples)); om <- numeric(nrow(lag)); z <- qa_standardize(y)
  for (j in seq_len(nrow(lag))) {
    h <- lag[j,1]; k <- lag[j,2]; t <- seq_len(n-k)
    code <- cat[t]+K*cat[t+h]+K^2*cat[t+k]+1L
    km[j,] <- as.numeric(crossprod(tabulate(code,nbins=K^3),w3))/length(t)
    om[j] <- mean(z[t]*z[t+h]*z[t+k])
  }
  weights <- (1-lag[,1]/M)*(1-lag[,2]/M)*(1-(lag[,2]-lag[,1])/M)
  freq <- seq(-fs/2,fs/2,length.out=cfg$FREQ_GRID)
  surfaces <- list(); coeffs <- list()
  for (j in seq_len(nrow(cfg$PLOT_TUPLES))) {
    tau <- cfg$PLOT_TUPLES[j,]; name <- paste0("QBP_",paste(tau,collapse="_"))
    co <- qa_coefficients(km,lag,g,tau,weights)
    surfaces[[name]] <- qa_surface(co,freq,fs); coeffs[[name]] <- co
  }
  co <- qa_coefficients(matrix(rep(om,nrow(g$triples)),nrow(lag)),lag,g,c(.5,.5,.5),weights)
  surfaces$Ordinary_standardized <- qa_surface(co,freq,fs); coeffs$Ordinary_standardized <- co
  f2 <- seq(0,fs/2,length.out=2L*cfg$FREQ_GRID-1L)
  pairs <- list()
  for (j in seq_len(nrow(g$pairs))) {
    a <- g$pairs[j,1]; b <- g$pairs[j,2]
    cp <- cn <- numeric(H)
    for (h in seq_len(H)) {
      t <- seq_len(n-h); cp[h] <- mean(rk$U[t,a]*rk$U[t+h,b]); cn[h] <- mean(rk$U[t,b]*rk$U[t+h,a])
    }
    c0 <- mean(rk$U[,a]*rk$U[,b]); h <- seq_len(H); w <- 1-h/M
    s <- (c0+as.numeric(w*cp)%*%exp(-2i*pi*outer(h,f2)/fs)+
           as.numeric(w*cn)%*%exp(2i*pi*outer(h,f2)/fs))/fs
    pairs[[j]] <- data.frame(tau1=cfg$LEVELS[a],tau2=cfg$LEVELS[b],frequency= f2,
                             real=Re(as.vector(s)),imaginary=Im(as.vector(s)),modulus=Mod(as.vector(s)))
  }
  list(frequency=freq,surfaces=surfaces,coefficients=coeffs,pairwise=do.call(rbind,pairs),
       H=H,M=M,fs=fs,tied=rk$tied,centering=rk$center)
}

qa_quality <- function(y) {
  cuts <- split(seq_along(y),cut(seq_along(y),breaks=8,labels=FALSE))
  ss <- vapply(cuts,function(i) sd(y[i]),numeric(1)); mm <- vapply(cuts,function(i) mean(y[i]),numeric(1))
  r <- rle(sort(y)); counts <- r$lengths
  data.frame(n=length(y),mean=mean(y),sd=sd(y),minimum=min(y),maximum=max(y),
    duplicate_fraction=1-length(unique(y))/length(y),largest_atom=max(counts)/length(y),
    local_sd_ratio=if(min(ss)>0) max(ss)/min(ss) else Inf,
    local_mean_range_over_sd=diff(range(mm))/sd(y),
    inference_eligible_no_ties=!anyDuplicated(y),stringsAsFactors=FALSE)
}
qa_invariance <- function(y,cfg) {

  z <- qa_standardize(y); changed <- asinh(z)
  a <- rank(y,ties.method="max"); b <- rank(changed,ties.method="max")
  data.frame(transformation="asinh(standardized signal)",max_rank_difference=max(abs(a-b)))
}
qa_plot <- function(job,sp,quality,out,cfg) {
  grDevices::pdf(file.path(out,"diagnostics.pdf"),width=10,height=7,onefile=TRUE)
  dev <- grDevices::dev.cur(); on.exit(if(dev %in% grDevices::dev.list()) grDevices::dev.off(dev),add=TRUE)
  par(mfrow=c(2,2),mar=c(4,4,3,1))
  plot(job$time,job$y,type="l",col="#325C80",xlab=job$time_label,ylab=job$value_label,main=job$id)
  acf(job$y,lag.max=min(100L,length(job$y)%/%5L),main="Sample autocorrelation")
  hist(job$y,breaks=50,col="#ADC6D7",border="white",main="Marginal distribution",xlab=job$value_label)
  pg <- spec.pgram(job$y,taper=.1,detrend=FALSE,demean=TRUE,plot=FALSE,fast=FALSE)
  plot(pg$freq*job$fs,pg$spec/job$fs,type="l",log="y",col="#325C80",
       xlab=job$frequency_label,ylab="Spectral density",main="Ordinary periodogram (10% taper)")
  grDevices::dev.off(dev)
  grDevices::pdf(file.path(out,"bispectra.pdf"),width=11,height=4.6,onefile=TRUE)
  dev2 <- grDevices::dev.cur(); on.exit(if(dev2 %in% grDevices::dev.list()) grDevices::dev.off(dev2),add=TRUE)
  pal <- colorRampPalette(c("#244B73","white","#A33030"))(101)
  for (nm in names(sp$surfaces)) {
    Z <- sp$surfaces[[nm]]; lim <- max(abs(c(Re(Z),Im(Z))),1e-14)
    par(mfrow=c(1,2),mar=c(4.4,4.6,4,1))
    for (part in c("Real","Imaginary")) {
      zz <- if(part=="Real") Re(Z) else Im(Z)
      image(sp$frequency,sp$frequency,zz,col=pal,zlim=c(-lim,lim),
            xlab=paste("f1:",job$frequency_label),ylab=paste("f2:",job$frequency_label),
            main=paste(nm,part,sep="\n"))
      mtext(sprintf("Separate panel scale: +/- %.3g; lag window M=%d",lim,sp$M),side=3,line=.1,cex=.7)
    }
  }
  grDevices::dev.off(dev2)
  grDevices::pdf(file.path(out,"pairwise_quantile_spectra.pdf"),width=10,height=7)
  dev3 <- grDevices::dev.cur(); on.exit(if(dev3 %in% grDevices::dev.list()) grDevices::dev.off(dev3),add=TRUE)
  par(mfrow=c(3,3),mar=c(3.5,3.5,2,1)); pp <- sp$pairwise
  for (a in cfg$LEVELS) for (b in cfg$LEVELS) {
    v <- pp[pp$tau1==a & pp$tau2==b,]
    plot(v$frequency,v$real,type="l",col="#245B80",ylim=range(c(v$real,v$imaginary)),
         xlab=job$frequency_label,ylab="Density",main=paste(a,b,sep=", "))
    lines(v$frequency,v$imaginary,col="#AE493B",lty=2)
    legend("topright",c("Real","Imaginary"),col=c("#245B80","#AE493B"),lty=1:2,bty="n",cex=.7)
  }
  grDevices::dev.off(dev3)
}

qa_segment <- function(y,fs,record_id,cfg,metadata=list(),time=NULL,time_label="Time (seconds)",
                       value_label="Observed value",frequency_label="Frequency (Hz)") {
  if (is.null(time)) time <- (seq_along(y)-1)/fs
  if (length(time)!=length(y)) stop("Time and signal lengths differ.")
  nseg <- floor(length(y)/cfg$SEGMENT_N)
  nseg <- min(nseg,cfg$MAX_SEGMENTS_PER_RECORD)
  if (nseg<1) return(list())
  lapply(seq_len(nseg),function(j) {
    ii <- (j-1L)*cfg$SEGMENT_N+seq_len(cfg$SEGMENT_N)
    list(id=paste0(record_id,"_s",sprintf("%02d",j)),y=as.numeric(y[ii]),fs=fs,time=time[ii],
         time_label=time_label,value_label=value_label,frequency_label=frequency_label,
         metadata=c(metadata,list(source_record=record_id,segment=j,first_index=min(ii),last_index=max(ii),
            source_n=length(y),selected_total_n=nseg*cfg$SEGMENT_N,unselected_n=length(y)-nseg*cfg$SEGMENT_N)))
  })
}

qa_infer <- function(fit,cfg,seed) {
  idx <- fit$index; groups <- qa_groups(idx); groups <- Filter(length,groups)
  tests <- intervals <- list(); B <- as.integer(cfg$B)
  for (j in seq_len(nrow(fit$configs))) {
    co <- fit$configs[j,]; S <- fit$S[[j]]
    set.seed(as.integer((seed+co$block_length) %% 2147483646 + 1L))
    sd0 <- sqrt(colSums(S*S)/fit$N); se <- sd0/sqrt(fit$n)
    reasons <- vapply(names(groups),function(nm) {
      ix <- groups[[nm]]
      if(fit$tied && nm!="Ordinary_bispectrum") "ties: descriptive empirical-centred thresholds"
      else if(co$n_blocks<cfg$MIN_BLOCKS) "too few covariance blocks"
      else if(any(sd0[ix]<=1e-12)) "degenerate influence variance" else ""
    },"")
    obs <- lapply(names(groups),function(nm) {
      ix <- groups[[nm]]; fac <- if(nm=="Pairwise_rank") 1 else 6/(2*pi)^2
      c(energy=fit$n*fac*sum(idx$estimate[ix]^2/idx$reference_variance[ix]),
        maximum=if(all(sd0[ix]>1e-12)) sqrt(fit$n)*max(abs(idx$estimate[ix])/sd0[ix]) else NA_real_)
    }); names(obs) <- names(groups)
    hits <- matrix(0L,length(groups),2,dimnames=list(names(groups),c("energy","maximum")))
    families <- split(seq_len(nrow(idx)),idx$type)
    family_ok <- vapply(names(families),function(nm) {
      ix <- families[[nm]]
      all(sd0[ix]>1e-12) && co$n_blocks>=cfg$MIN_BLOCKS && !(fit$tied && nm!="ordinary3")
    },logical(1))
    cim <- lapply(families,function(ix) numeric(B))
    maxrows <- function(x) if(ncol(x)==1L) abs(x[,1]) else apply(abs(x),1,max)
    for(first in seq.int(1L,B,by=cfg$MULTIPLIER_CHUNK)) {
      at <- seq.int(first,min(B,first+cfg$MULTIPLIER_CHUNK-1L)); nb <- length(at)
      E <- matrix(rnorm(nrow(S)*nb),nrow(S),nb)
      Z <- crossprod(E,S)/sqrt(fit$N)
      Zs <- sweep(Z,2,pmax(sd0,1e-12),"/")
      for(nm in names(families)[family_ok]) cim[[nm]][at] <- maxrows(Zs[,families[[nm]],drop=FALSE])
      for(nm in names(groups)[!nzchar(reasons)]) {
        ix <- groups[[nm]]; fac <- if(nm=="Pairwise_rank") 1 else 6/(2*pi)^2
        simE <- fac*rowSums(sweep(Z[,ix,drop=FALSE]^2,2,idx$reference_variance[ix],"/"))
        simM <- maxrows(Zs[,ix,drop=FALSE]); tol <- 64*.Machine$double.eps*pmax(1,abs(obs[[nm]]))
        hits[nm,] <- hits[nm,]+c(sum(simE>=obs[[nm]][1]-tol[1]),sum(simM>=obs[[nm]][2]-tol[2]))
      }
    }
    ci <- idx; ci$se <- se
    ci$pointwise_lower <- idx$estimate-qnorm(1-cfg$ALPHA/2)*se
    ci$pointwise_upper <- idx$estimate+qnorm(1-cfg$ALPHA/2)*se
    ci$simultaneous_lower <- ci$simultaneous_upper <- NA_real_
    for(nm in names(families)) {
      ix <- families[[nm]]
      if(family_ok[nm]) {
        cr <- unname(quantile(cim[[nm]],1-cfg$ALPHA,type=1))
        ci$simultaneous_lower[ix] <- idx$estimate[ix]-cr*se[ix]
        ci$simultaneous_upper[ix] <- idx$estimate[ix]+cr*se[ix]
      } else ci[ix,c("se","pointwise_lower","pointwise_upper")] <- NA_real_
    }
    ci$alignment <- co$alignment; ci$block_length <- co$block_length; ci$n_blocks <- co$n_blocks
    intervals[[j]] <- ci
    for(nm in names(groups)) {
      count <- hits[nm,]; valid <- !nzchar(reasons[nm]); tail <- count/B

      lo <- ifelse(count==0,0,qbeta(.025,pmax(count,1),B-count+1))
      hi <- ifelse(count==B,1,qbeta(.975,count+1,pmax(B-count,1)))
      tests[[length(tests)+1L]] <- data.frame(method=nm,statistic_type=names(count),
        statistic=as.numeric(obs[[nm]]),p_value=if(valid) (1+count)/(B+1) else NA_real_,
        exceedances=if(valid) count else NA_integer_,
        mc_tail_lower=if(valid) lo else NA_real_,mc_tail_upper=if(valid) hi else NA_real_,
        mc_se=if(valid) sqrt(tail*(1-tail)/B) else NA_real_,
        dimension=length(groups[[nm]]),alignment=co$alignment,block_length=co$block_length,
        n_blocks=co$n_blocks,bandwidth=fit$bandwidth,B=B,
        status=if(valid) "computed" else unname(reasons[nm]),stringsAsFactors=FALSE)
    }
  }
  list(tests=qa_bind(tests),moments=qa_bind(intervals))
}

qs_code_hash <- function() {
  e <- environment(qs_code_hash); nm <- sort(QS_FUNCTION_NAMES)
  qa_hash(lapply(nm,function(n) paste(deparse(get(n,e),width.cutoff=500L),collapse="\n")))
}
qs_seed <- function(id,cfg) as.integer((cfg$SEED+strtoi(substr(qa_hash(id),1,7),16L)) %% 2147483646+1L)
qs_export <- function(cl) {
  e <- environment(qs_export)
  parallel::clusterExport(cl,c(QS_FUNCTION_NAMES,"QA_VERSION","QS_FUNCTION_NAMES"),envir=e)
}
qs_parallel <- function(tasks,fun,cfg,folder) {
  dir.create(folder,recursive=TRUE,showWarnings=FALSE)
  nw <- min(cfg$WORKERS,length(tasks)); if(!length(tasks)) return(list())
  if(nw>1L) {

    cl <- parallel::makePSOCKcluster(nw,outfile=file.path(folder,"workers.log"))
    on.exit(parallel::stopCluster(cl),add=TRUE); qs_export(cl)
  }
  ans <- vector("list",length(tasks))
  for(first in seq.int(1L,length(tasks),by=nw)) {
    at <- seq.int(first,min(length(tasks),first+nw-1L))
    ans[at] <- if(nw==1L) lapply(tasks[at],fun,cfg=cfg) else parallel::parLapplyLB(cl,tasks[at],fun,cfg=cfg)
    message(basename(folder),": ",max(at),"/",length(tasks)," jobs completed")
  }
  ans
}
qs_files <- function(folder) {
  if(!dir.exists(folder)) stop("INPUT_DIR does not exist: ",folder)
  z <- list.files(folder,recursive=TRUE,full.names=TRUE)
  z[!grepl("(^|[/\\\\])__MACOSX([/\\\\]|$)",z) & !startsWith(basename(z),"._")]
}
qs_find <- function(paths,name,required=TRUE) {
  z <- paths[tolower(basename(paths))==tolower(name)]
  if(!length(z)) {
    if(required) stop("Missing local input: ",name) else return(NULL)
  }
  if(length(z)>1L && length(unique(unname(tools::md5sum(z))))>1L)
    stop("Conflicting local copies of ",name,"; keep one authoritative copy in INPUT_DIR.")
  z[1]
}
qs_quality <- function(job) {
  q <- qa_quality(job$y); t <- seq_along(job$y)
  slope <- coef(lm(job$y~t))[2]
  q$linear_trend_range_over_sd <- abs(slope)*(length(t)-1)/sd(job$y)
  q$raw_duplicate_fraction <- 1-length(unique(job$raw_y))/length(job$raw_y)
  q$transformation <- job$transformation; q$duration_seconds <- length(job$y)/job$fs
  q$record_id <- job$id; q$source_record <- job$metadata$source_record
  q
}
qs_tie_check <- function(y,cfg) {
  n <- length(y); lower <- rank(y,ties.method="min")/n; upper <- rank(y,ties.method="max")/n
  points <- sort(unique(cfg$LAG_POINTS)); lag <- t(combn(points,2)); tt <- seq_len(n-max(points))
  g <- qa_grid(cfg$LEVELS); A <- outer(lower,cfg$LEVELS,"<=")*1; B <- outer(upper,cfg$LEVELS,"<=")*1
  z <- data.frame(tau=cfg$LEVELS,duplicate_excess=n-sum(!duplicated(y)),
    threshold_disagreements=colSums(A!=B),fraction_disagreements=colMeans(A!=B))
  A <- sweep(A,2,cfg$LEVELS,"-"); B <- sweep(B,2,cfg$LEVELS,"-"); delta <- 0
  for(i in seq_len(nrow(lag))) {
    h <- lag[i,1]; k <- lag[i,2]; a<-g$triples[,1];b<-g$triples[,2];c<-g$triples[,3]
    ka <- colMeans(A[tt,a,drop=FALSE]*A[tt+h,b,drop=FALSE]*A[tt+k,c,drop=FALSE])
    kb <- colMeans(B[tt,a,drop=FALSE]*B[tt+h,b,drop=FALSE]*B[tt+k,c,drop=FALSE])
    delta <- max(delta,abs(ka-kb))
  }
  z$max_canonical_moment_difference <- delta
  z$note <- "Lower/upper rank threshold sensitivity only; this does not validate inference with ties."
  z
}
qs_worker <- function(task,cfg) {
  job <- task$job; cc <- task$cfg; folder <- task$folder
  dir.create(folder,recursive=TRUE,showWarnings=FALSE); checkpoint <- file.path(folder,"result.rds")
  old <- if(file.exists(checkpoint)) tryCatch(readRDS(checkpoint),error=function(e) NULL) else NULL
  if(!is.null(old) && identical(old$fingerprint,task$fingerprint) && old$status=="ok") {
    old$cached <- TRUE; return(old)
  }
  notes <- character(); start <- proc.time()[["elapsed"]]
  ans <- tryCatch(withCallingHandlers({
    if(any(!is.finite(job$y)) || length(job$y)<cc$MIN_N || sd(job$y)<=0)
      stop("Segment is not complete, finite and nonconstant.")
    fit <- qa_fit(job$y,cc)
    if(task$stage=="linear_detrend") cc$B<-99L
    inf <- qa_infer(fit,cc,task$seed)
    if(task$stage=="linear_detrend") {
      inf$tests[,c("p_value","exceedances","mc_tail_lower","mc_tail_upper","mc_se","B")]<-NA
      inf$tests$status<-"descriptive: estimated linear detrending is not calibrated"
      inf$moments[,c("se","pointwise_lower","pointwise_upper","simultaneous_lower","simultaneous_upper")]<-NA
    }
    quality <- qs_quality(job); tie <- qs_tie_check(job$raw_y,cc)
    maps <- lapply(if(task$stage=="primary") cfg$MAP_H_VALUES else cfg$MAP_H,function(H) {
      mc <- cc; mc$MAP_H <- H; qa_spectra(job$y,job$fs,mc)
    }); names(maps) <- paste0("H",if(task$stage=="primary") cfg$MAP_H_VALUES else cfg$MAP_H)
    for(nm in c("tests","moments")) {inf[[nm]]$record_id<-job$id;inf[[nm]]$stage<-task$stage}
    qa_csv(inf$tests,file.path(folder,"tests.csv")); qa_csv(inf$moments,file.path(folder,"moments.csv"))
    qa_csv(quality,file.path(folder,"quality.csv")); qa_csv(tie,file.path(folder,"ties.csv"))
    qa_save(job,file.path(folder,"input_segment.rds")); qa_save(maps,file.path(folder,"spectra.rds"))
    if(cfg$MAKE_PLOTS && task$stage=="primary") qa_plot(job,maps[[paste0("H",cfg$MAP_H)]],quality,folder,cc)
    if(task$stage=="primary" && cfg$RUN_EXTENDED_LAGS) {
      ec <- cc; ec$LAG_POINTS <- sort(unique(c(cc$LAG_POINTS,32L))); ec$B <- cfg$B_SENSITIVITY
      ext <- qa_infer(qa_fit(job$y,ec),ec,task$seed)
      ext$tests$record_id <- job$id; ext$tests$stage <- "extended_lags"
      qa_csv(ext$tests,file.path(folder,"extended_lags_tests.csv"))
    } else ext <- NULL
    list(status="ok",tests=inf$tests,quality=quality,ties=tie,maps=maps,
      extended=if(is.null(ext)) NULL else ext$tests,moments=inf$moments,
      metadata=job$metadata,cached=FALSE)
  },warning=function(w) {notes<<-c(notes,conditionMessage(w));invokeRestart("muffleWarning")}),
  error=function(e) list(status="error",error=conditionMessage(e),cached=FALSE))
  ans$id <- job$id; ans$stage<-task$stage;ans$fingerprint<-task$fingerprint
  ans$warnings<-unique(notes); ans$elapsed<-proc.time()[["elapsed"]]-start
  qa_save(ans,checkpoint);ans
}
qs_adjust <- function(tests,cfg,planned_tests) {
  if(!nrow(tests)) return(tests)
  tests$reference_configuration <- tests$alignment==cfg$PRIMARY_ALIGNMENT & tests$block_length==cfg$PRIMARY_BLOCK
  tests$p_holm <- tests$mc_holm_lower <- tests$mc_holm_upper <- NA_real_
  tests$holm_family_size <- planned_tests

  at <- which(tests$reference_configuration & is.finite(tests$p_value))
  if(length(at)) {
    tests$p_holm[at] <- p.adjust(tests$p_value[at],"holm",n=planned_tests)
    tests$mc_holm_lower[at] <- p.adjust(tests$mc_tail_lower[at],"holm",n=planned_tests)
    tests$mc_holm_upper[at] <- p.adjust(tests$mc_tail_upper[at],"holm",n=planned_tests)
  }
  tests$min_raw_p <- 1/(tests$B+1)
  tests$floor_times_family <- planned_tests/(tests$B+1)

  tests
}
qs_similarity <- function(a,b) {
  d <- merge(a,b,by=c("h","k"),all=TRUE,suffixes=c("_a","_b"));d[is.na(d)]<-0
  x<-d$value_a;y<-d$value_b
  den <- sqrt(sum(x*x)*sum(y*y))
  c(cosine=if(den>0) sum(x*y)/den else NA_real_,
    relative_L2=if(sum(x*x)>0) sqrt(sum((x-y)^2)/sum(x*x)) else NA_real_)
}
qs_summaries <- function(ans,cfg,folder) {
  ok <- Filter(function(a) a$status=="ok",ans);rows<-list(); smooth<-list();strength<-list()
  for(a in ok) {
    base <- a$maps[[paste0("H",cfg$MAP_H)]]
    for(nm in names(base$coefficients)) {
      c0 <- base$coefficients[[nm]]; tau <- if(startsWith(nm,"QBP")) as.numeric(strsplit(sub("QBP_","",nm),"_")[[1]]) else NULL
      strength[[length(strength)+1L]] <- data.frame(record_id=a$id,method=nm,
        weighted_coefficient_energy=sum(c0$value^2),
        iid_reference_scaled_energy=sum(c0$value^2)/if(is.null(tau)) 1 else prod(tau*(1-tau)),
        interpretation="descriptive energy; ordinary and quantile units differ")
      for(H in setdiff(cfg$MAP_H_VALUES,cfg$MAP_H)) if(!is.null(a$maps[[paste0("H",H)]])) {
        sim<-qs_similarity(c0,a$maps[[paste0("H",H)]]$coefficients[[nm]])
        smooth[[length(smooth)+1L]]<-data.frame(record_id=a$id,method=nm,H_reference=cfg$MAP_H,H=H,t(sim))
      }
    }
  }
  sources <- unique(vapply(ok,function(a) a$metadata$source_record,""))
  for(src in sources) {
    z<-Filter(function(a) a$metadata$source_record==src,ok)
    if(length(z)<2L) next
    z<-z[order(vapply(z,function(a) a$metadata$segment,numeric(1)))]
    for(i in seq_len(length(z)-1L)) for(nm in names(z[[i]]$maps[[paste0("H",cfg$MAP_H)]]$coefficients)) {
      sim<-qs_similarity(z[[i]]$maps[[paste0("H",cfg$MAP_H)]]$coefficients[[nm]],
        z[[i+1]]$maps[[paste0("H",cfg$MAP_H)]]$coefficients[[nm]])
      rows[[length(rows)+1L]]<-data.frame(source_record=src,record_a=z[[i]]$id,record_b=z[[i+1]]$id,method=nm,t(sim))
    }
  }
  qa_csv(qa_bind(rows),file.path(folder,"adjacent_segment_similarity.csv"))
  qa_csv(qa_bind(smooth),file.path(folder,"map_smoothing_sensitivity.csv"))
  qa_csv(qa_bind(strength),file.path(folder,"descriptive_spectral_energy.csv"))
  if(cfg$MAKE_PLOTS && length(ok)) qs_shared_maps(ok,cfg,folder)
}
qs_shared_maps <- function(ok,cfg,folder) {

  grDevices::pdf(file.path(folder,"shared_scale_maps.pdf"),width=11,height=8.5,onefile=TRUE)
  on.exit(grDevices::dev.off(),add=TRUE)
  methods<-names(ok[[1]]$maps[[paste0("H",cfg$MAP_H)]]$surfaces)
  for(nm in methods) for(part in c("Real","Imaginary")) {
    fun<-if(part=="Real") Re else Im
    lim<-max(vapply(ok,function(a) max(abs(fun(a$maps[[paste0("H",cfg$MAP_H)]]$surfaces[[nm]]))),numeric(1)))
    if(lim<=0) lim<-1e-12
    par(mfrow=c(2,3),mar=c(4.3,4.5,2.4,1),oma=c(0,0,3,0),mgp=c(2.5,.7,0),cex.axis=.85,cex.lab=.85)
    for(ii in seq_along(ok)) {
      a<-ok[[ii]]
      sp<-a$maps[[paste0("H",cfg$MAP_H)]]
      image(sp$frequency,sp$frequency,fun(sp$surfaces[[nm]]),zlim=c(-lim,lim),
        col=hcl.colors(61,"Blue-Red 3"),xlab="Frequency (Hz)",ylab="Frequency (Hz)",
        main=a$id,cex.main=.9)
      if((ii-1L) %% 6L==0L) mtext(paste(nm,part,sprintf("Shared limits: +/- %.3g",lim),sep="  |  "),
        side=3,outer=TRUE,line=1,cex=.85)
    }
    remainder<-length(ok) %% 6L
    if(remainder) for(i in seq_len(6L-remainder)) plot.new()
  }
}

qs_paired_null <- function(n,rho=.8) {
  y<-numeric(n); i<-1L
  state<-sample(c("singleton","first","second"),1,prob=c(1,1,1))
  while(i<=n) {
    if(state=="first") {
      z<-rnorm(2);y[i]<-z[1]
      if(i<n) y[i+1L]<-rho*z[1]+sqrt(1-rho*rho)*z[2]
      i<-i+2L
    } else {y[i]<-rnorm(1);i<-i+1L}
    state<-sample(c("singleton","first"),1)
  }
  y
}
qs_cal_worker <- function(task,cfg) {
  f<-file.path(task$folder,paste0(task$id,".rds"));old<-if(file.exists(f)) tryCatch(readRDS(f),error=function(e) NULL) else NULL
  if(!is.null(old) && identical(old$fingerprint,task$fingerprint) && old$status=="ok") return(old)
  notes<-character()
  a<-tryCatch(withCallingHandlers({
    set.seed(task$seed); n<-task$n; model<-task$model;cc<-task$cfg
    y<-switch(model,iid=rnorm(n),paired_null=qs_paired_null(n),
      AR04_median=as.numeric(arima.sim(list(ar=.4),n=n)),
      AR07_median=as.numeric(arima.sim(list(ar=.7),n=n)))
    if(grepl("median",model)) cc$LEVELS<-.5
    out<-qa_infer(qa_fit(y,cc),cc,task$seed+101L)$tests

    keep<-if(grepl("median",model)) out$method %in% c("QBP_median","Ordinary_bispectrum") else
      if(model=="paired_null") out$method!="Pairwise_rank" else rep(TRUE,nrow(out))
    out<-out[keep,];out$model<-model;out$n<-n;out$replication<-task$replication
    list(status="ok",tests=out)
  },warning=function(w) {notes<<-c(notes,conditionMessage(w));invokeRestart("muffleWarning")}),
  error=function(e) list(status="error",error=conditionMessage(e)))
  a$id<-task$id;a$fingerprint<-task$fingerprint;a$warnings<-unique(notes);qa_save(a,f);a
}
qs_calibration <- function(cfg,root,code_hash) {
  if(!cfg$RUN_CALIBRATION) return(invisible(NULL))
  cc<-cfg;cc$B<-cfg$CALIBRATION_B;cc$MAP_H_VALUES<-NULL; cc$MAKE_PLOTS<-FALSE
  sig<-substr(qa_hash(list(code_hash,cfg$DATASET,cc$B,
    cfg$SEED,cfg$BLOCK_LENGTHS,cfg$LAG_POINTS,cfg$BW_FACTOR,cfg$ALIGNMENTS,cfg$MIN_BLOCKS)),1,12)
  folder<-file.path(root,paste0("calibration_",sig));dir.create(folder,recursive=TRUE,showWarnings=FALSE)
  tasks<-list()
  for(n in cfg$CALIBRATION_N) for(model in c("iid","paired_null","AR04_median","AR07_median"))
    for(r in seq_len(cfg$CALIBRATION_REPS)) {
      cc$BLOCK_LENGTHS<-as.integer(cfg$BLOCK_LENGTHS*n/8192L)
      id<-paste(model,n,sprintf("%05d",r),sep="_")
      tasks[[length(tasks)+1L]]<-list(id=id,n=n,model=model,replication=r,cfg=cc,folder=folder,
        seed=qs_seed(id,cfg),fingerprint=qa_hash(list(sig,id)))
    }
  ans<-qs_parallel(tasks,qs_cal_worker,cfg,folder)
  ok<-Filter(function(a) a$status=="ok",ans);all<-qa_bind(lapply(ok,`[[`,"tests"))
  qa_csv(all,file.path(folder,"replications.csv"));qa_save(cfg,file.path(folder,"configuration.rds"))
  rows<-list()
  if(nrow(all)) {
    by<-interaction(all[,c("model","n","method","statistic_type","alignment","block_length")],drop=TRUE)
    for(z in split(all,by)) {
      p<-z$p_value[is.finite(z$p_value)];R<-length(p); k<-sum(p<cfg$ALPHA)
      ci<-if(R) binom.test(k,R)$conf.int else c(NA_real_,NA_real_)
      rows[[length(rows)+1L]]<-cbind(z[1,c("model","n","method","statistic_type","alignment","block_length")],
        data.frame(completed=R,planned=cfg$CALIBRATION_REPS,rejections=k,
          rejection_rate=if(R) k/R else NA_real_,mc_lower=ci[1],mc_upper=ci[2],nominal=cfg$ALPHA))
    }
  }
  qa_csv(qa_bind(rows),file.path(folder,"calibration_summary.csv"))
  qa_csv(qa_bind(lapply(ans,function(a) if(a$status=="error") data.frame(id=a$id,error=a$error))),file.path(folder,"errors.csv"))
  qa_csv(qa_bind(lapply(ans,function(a) if(length(a$warnings)) data.frame(id=a$id,warning=a$warnings))),file.path(folder,"warnings.csv"))
  invisible(folder)
}

qs_stage_cfg <- function(cfg,stage) {
  cc<-cfg;cc$B<-if(stage=="primary") cfg$B_PRIMARY else cfg$B_SENSITIVITY
  cc$SEGMENT_N<-if(stage=="short_window") 4096L else 8192L
  cc$MAX_SEGMENTS_PER_RECORD<-if(stage=="short_window") 4L else 2L
  if(stage=="short_window") {
    cc$BLOCK_LENGTHS<-as.integer(cfg$BLOCK_LENGTHS/2L);cc$PRIMARY_BLOCK<-cfg$PRIMARY_BLOCK/2L
  }
  if(stage=="filter_0900Hz") cc$FIR_CUTOFF_FRACTION<-.6
  if(stage=="filter_1350Hz") cc$FIR_CUTOFF_FRACTION<-.9
  cc
}
qs_main <- function(cfg) {
  stopifnot(cfg$WORKERS>=1,cfg$MULTIPLIER_CHUNK>=1,cfg$B_PRIMARY>=99,cfg$B_SENSITIVITY>=99,
    cfg$PRIMARY_BLOCK %in% cfg$BLOCK_LENGTHS,cfg$MAP_H %in% cfg$MAP_H_VALUES,
    all(cfg$CALIBRATION_N %in% c(4096L,8192L)))
  Sys.setenv(OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",MKL_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1")
  if(requireNamespace("RhpcBLASctl",quietly=TRUE)) RhpcBLASctl::blas_set_num_threads(1)
  dir.create(cfg$OUTPUT_DIR,recursive=TRUE,showWarnings=FALSE)
  code<-qs_code_hash(); signatures<-list();outputs<-list()
  for(stage in cfg$STAGES) {
    cc<-qs_stage_cfg(cfg,stage)
    numerical<-cc[setdiff(names(cc),c("WORKERS","INPUT_DIR","OUTPUT_DIR","STAGES","MULTIPLIER_CHUNK","CALIBRATION_REPS","CALIBRATION_B","RUN_CALIBRATION","CALIBRATION_N"))]
    sig<-substr(qa_hash(list(code,numerical,stage)),1,12)
    folder<-file.path(cfg$OUTPUT_DIR,paste0(stage,"_",sig));dir.create(folder,recursive=TRUE,showWarnings=FALSE)
    qa_save(cc,file.path(folder,"configuration.rds"));dput(cc,file=file.path(folder,"configuration.txt"))
    capture.output(sessionInfo(),file=file.path(folder,"sessionInfo.txt"))
    loaded<-qs_load(cc,stage,folder);jobs<-loaded$jobs
    tasks<-lapply(jobs,function(job) list(job=job,cfg=cc,stage=stage,folder=file.path(folder,"records",job$id),
      seed=qs_seed(job$id,cfg),fingerprint=qa_hash(list(code,numerical,stage,job))))
    ans<-qs_parallel(tasks,qs_worker,cfg,folder);ok<-Filter(function(a) a$status=="ok",ans)
    planned<-loaded$planned_segments*12L
    tests<-qs_adjust(qa_bind(lapply(ok,`[[`,"tests")),cc,planned)
    ext<-qs_adjust(qa_bind(lapply(ok,`[[`,"extended")),cc,planned)
    qa_csv(tests,file.path(folder,"tests_all.csv"));qa_csv(ext,file.path(folder,"extended_lags_tests.csv"))
    qa_csv(qa_bind(lapply(ok,`[[`,"quality")),file.path(folder,"quality_all.csv"))
    qa_csv(qa_bind(lapply(ok,function(a) cbind(record_id=a$id,a$ties))),file.path(folder,"ties_all.csv"))
    errors<-qa_bind(lapply(ans,function(a) if(a$status=="error") data.frame(record_id=a$id,error=a$error)))
    warns<-qa_bind(lapply(ans,function(a) if(length(a$warnings)) data.frame(record_id=a$id,warning=a$warnings)))
    qa_csv(errors,file.path(folder,"errors.csv"));qa_csv(warns,file.path(folder,"warnings.csv"))
    qs_summaries(ans,cc,folder)
    qa_save(list(configuration=cc,tests=tests,extended=ext,results=ans,input_errors=loaded$errors),
      file.path(folder,"supplement_bundle.rds"))
    outputs[[stage]]<-list(folder=folder,tests=tests,quality=qa_bind(lapply(ok,`[[`,"quality")))
    signatures[[stage]]<-data.frame(stage=stage,folder=normalizePath(folder,winslash="/"),
      planned_segments=loaded$planned_segments,completed_segments=length(ok),input_errors=nrow(loaded$errors),
      analysis_errors=nrow(errors),reserved_Holm_family=planned,B=cc$B)
    message(stage,": ",length(ok)," segments; ",nrow(loaded$errors)," input errors; ",nrow(errors)," analysis errors.")
  }
  qa_csv(qa_bind(signatures),file.path(cfg$OUTPUT_DIR,"run_index.csv"))
  qa_csv(qa_bind(lapply(outputs,`[[`,"tests")),file.path(cfg$OUTPUT_DIR,"all_stages_tests.csv"))
  qa_save(outputs,file.path(cfg$OUTPUT_DIR,"all_stages_summary.rds"))
  qs_compare_stages(outputs,cfg)
  cal<-qs_calibration(cfg,cfg$OUTPUT_DIR,code)
  writeLines(if(is.null(cal)) "Calibration disabled" else normalizePath(cal,winslash="/"),file.path(cfg$OUTPUT_DIR,"calibration_location.txt"))
  message("Finished. Start with run_index.csv, all_stages_tests.csv and calibration_summary.csv.")
  invisible(outputs)
}
qs_compare_stages <- function(outputs,cfg) {
  if(is.null(outputs$primary)) return(invisible(NULL))
  base<-outputs$primary$tests; if(!nrow(base)) return(invisible(NULL))
  base<-base[base$reference_configuration,]
  rows<-list()
  for(nm in setdiff(names(outputs),c("primary","short_window"))) {
    other<-outputs[[nm]]$tests;if(!nrow(other)) next
    other<-other[other$reference_configuration,]
    z<-merge(base[,c("record_id","method","statistic_type","p_value","p_holm")],
      other[,c("record_id","method","statistic_type","p_value","p_holm")],
      by=c("record_id","method","statistic_type"),suffixes=c("_primary","_sensitivity"))
    z$sensitivity<-nm;rows[[nm]]<-z
  }
  qa_csv(qa_bind(rows),file.path(cfg$OUTPUT_DIR,"matched_sensitivity.csv"))
  maps<-list()
  for(nm in setdiff(names(outputs),c("primary","short_window"))) {
    for(id in unique(base$record_id)) {
      f1<-file.path(outputs$primary$folder,"records",id,"spectra.rds")
      f2<-file.path(outputs[[nm]]$folder,"records",id,"spectra.rds")
      if(!file.exists(f1) || !file.exists(f2)) next
      a<-readRDS(f1)[[paste0("H",cfg$MAP_H)]];b<-readRDS(f2)[[paste0("H",cfg$MAP_H)]]
      for(method in names(a$coefficients)) {
        sim<-qs_similarity(a$coefficients[[method]],b$coefficients[[method]])
        maps[[length(maps)+1L]]<-data.frame(record_id=id,sensitivity=nm,method=method,t(sim))
      }
    }
  }
  qa_csv(qa_bind(maps),file.path(cfg$OUTPUT_DIR,"matched_spectral_sensitivity.csv"))
}

qa_fir_decimate <- function(y,fs,factor=16L,half_width_per_factor=12L,cutoff_fraction=.8) {
  factor <- as.integer(factor)
  if(factor==1L) return(list(y=y,fs=fs,time=(seq_along(y)-1)/fs,filter=numeric(),trim_each=0L))
  stopifnot(factor>=2L,cutoff_fraction>0,cutoff_fraction<1,half_width_per_factor>=4)
  half <- as.integer(half_width_per_factor*factor); j <- -half:half
  fc <- cutoff_fraction/(2*factor)
  sinc <- function(x) {z <- rep(1,length(x)); nz <- x!=0;z[nz] <- sin(pi*x[nz])/(pi*x[nz]);z}
  window <- .42+.5*cos(pi*j/half)+.08*cos(2*pi*j/half)
  kernel <- 2*fc*sinc(2*fc*j)*window; kernel <- kernel/sum(kernel)
  filtered <- as.numeric(stats::filter(y,kernel,sides=2,method="convolution"))
  take <- seq.int(half+1L,length(y)-half,by=factor)
  list(y=filtered[take],fs=fs/factor,time=(take-1L)/fs,filter=kernel,trim_each=half)
}

qs_load <- function(cfg,stage,folder) {
  if(!requireNamespace("R.matlab",quietly=TRUE))
    stop("Package R.matlab is required. Install once with install.packages('R.matlab').")
  manifest<-rbind(data.frame(condition="Normal",load_hp=0:3,file_id=97:100),
    data.frame(condition="IR007",load_hp=0:3,file_id=109:112),
    data.frame(condition="OR007_6oclock",load_hp=0:3,file_id=135:138))
  manifest<-manifest[manifest$load_hp %in% cfg$LOADS & manifest$condition %in% cfg$CONDITIONS,]
  paths<-qs_files(cfg$INPUT_DIR);jobs<-inv<-errors<-list()
  qa_csv(manifest,file.path(folder,"source_manifest.csv"))
  for(i in seq_len(nrow(manifest))) {
    row<-manifest[i,];id<-paste(row$condition,paste0("HP",row$load_hp),sep="_")
    got<-tryCatch({

      path<-qs_find(paths,paste0(row$file_id,".mat"),required=FALSE)
      temp<-qs_find(paths,paste0(row$file_id,".mat.download"),required=FALSE)
      candidates<-unique(c(path,temp))
      if(!length(candidates)) stop("Missing local ",row$file_id,".mat (and .mat.download).")
      raw<-NULL;why<-character()
      for(p in candidates) {
        z<-tryCatch(qs_cwru_read(p,row$file_id),error=function(e) e)
        if(!inherits(z,"error")) {raw<-z;path<-p;break}
        why<-c(why,paste(basename(p),conditionMessage(z)))
      }
      if(is.null(raw)) stop(paste(why,collapse=" | "))
      fil<-qa_fir_decimate(raw$y,cfg$RAW_FS,cfg$DECIMATE_FACTOR,
        cfg$FIR_HALF_WIDTH_PER_FACTOR,cfg$FIR_CUTOFF_FRACTION)

      span<-min(2L,length(fil$y)%/%8192L)*8192L
      if(span<8192L) stop("Fewer than 8192 usable filtered observations.")
      metadata<-list(dataset="CWRU",condition=row$condition,load_hp=row$load_hp,file_id=row$file_id,
        source=normalizePath(path,winslash="/"),source_md5=unname(tools::md5sum(path)),
        channel=raw$variable,available_channels=paste(raw$available,collapse=";"),rpm=raw$rpm,
        raw_fs=cfg$RAW_FS,analysis_fs=fil$fs,decimation=cfg$DECIMATE_FACTOR,
        filter_coefficients=fil$filter,trim_each_raw_samples=fil$trim_each,
        cutoff_hz=cfg$FIR_CUTOFF_FRACTION*fil$fs/2,
        raw_duplicate_fraction=1-length(unique(raw$y))/length(raw$y),
        target="FIR low-pass filtered acceleration; each cutoff defines a different target")
      seg<-qa_segment(fil$y[seq_len(span)],fil$fs,id,cfg,metadata=metadata,time=fil$time[seq_len(span)],
        value_label="Filtered drive-end acceleration (g)")
      for(j in seq_along(seg)) {
        seg[[j]]$raw_y<-seg[[j]]$y;seg[[j]]$transformation<-paste0("low-pass ",metadata$cutoff_hz," Hz")
      }
      list(jobs=seg,inventory=data.frame(record_id=id,file_id=row$file_id,path=path,channel=raw$variable,
        available_channels=paste(raw$available,collapse=";"),rpm=raw$rpm,raw_n=length(raw$y),
        filtered_n=length(fil$y),selected_span_n=span,unselected_n=length(fil$y)-span,
        selected_segments=length(seg),cutoff_hz=metadata$cutoff_hz,
        raw_duplicate_fraction=metadata$raw_duplicate_fraction))
    },error=function(e) list(error=conditionMessage(e)))
    if(!is.null(got$error)) errors[[length(errors)+1L]]<-data.frame(record_id=id,error=got$error)
    else {jobs<-c(jobs,got$jobs);inv[[length(inv)+1L]]<-got$inventory}
  }
  err<-qa_bind(errors);qa_csv(err,file.path(folder,"input_errors.csv"))
  qa_csv(qa_bind(inv),file.path(folder,"input_inventory.csv"))
  list(jobs=jobs,errors=err,planned_segments=nrow(manifest)*cfg$MAX_SEGMENTS_PER_RECORD)
}
qs_cwru_read <- function(path,file_id) {
  m<-R.matlab::readMat(path)
  de<-grep("[_.]DE[_.]time$",names(m),ignore.case=TRUE)
  exact<-grep(paste0("^X0*",as.integer(file_id),"[_.]DE[_.]time$"),names(m),ignore.case=TRUE)
  if(length(exact)!=1L) stop("Expected exactly one channel matching file ID ",file_id,
    "; DE candidates are: ",paste(names(m)[de],collapse=", "))

  y<-as.numeric(m[[exact]])
  if(length(y)<10000L || any(!is.finite(y)) || sd(y)<=0) stop("Invalid or incomplete acceleration channel.")
  rpmhit<-grep(paste0("^X0*",as.integer(file_id),"[_.]RPM$"),names(m),ignore.case=TRUE)
  list(y=y,variable=names(m)[exact],available=names(m)[de],
    rpm=if(length(rpmhit)==1L) as.numeric(m[[rpmhit]])[1] else NA_real_)
}

QS_FUNCTION_NAMES <- c("qa_script_dir","qa_hash","qa_save","qa_csv","qa_bind","qa_grid","qa_rank","qa_block_sum","qa_standardize","qa_fit","qa_groups","qa_coefficients","qa_surface","qa_spectra","qa_quality","qa_invariance","qa_plot","qa_segment","qa_infer","qs_code_hash","qs_seed","qs_export","qs_parallel","qs_files","qs_find","qs_quality","qs_tie_check","qs_worker","qs_adjust","qs_similarity","qs_summaries","qs_shared_maps","qs_paired_null","qs_cal_worker","qs_calibration","qs_stage_cfg","qs_main","qs_compare_stages","qa_fir_decimate","qs_load","qs_cwru_read")
if (!isTRUE(getOption("qbp.skip.autorun",FALSE))) qs_main(CONFIG)
