qbd_entry_root <- function() {
  frames <- sys.frames()
  for (i in rev(seq_along(frames))) {
    of <- frames[[i]]$ofile
    if (!is.null(of) && length(of) == 1L && file.exists(of))
      return(dirname(normalizePath(of, winslash = "/")))
  }
  args <- commandArgs(trailingOnly = FALSE)
  filearg <- args[grepl("^--file=", args)]
  if (length(filearg)) {
    path <- sub("^--file=", "", filearg[1L])
    if (!file.exists(path)) path <- gsub("~+~", " ", path, fixed = TRUE)
    return(dirname(normalizePath(path, winslash = "/", mustWork = TRUE)))
  }
  if (file.exists("config.R")) return(normalizePath(getwd(), winslash = "/"))
  stop("Cannot locate the project directory. Set the working directory to the extracted code folder.")
}

QBD_ROOT <- qbd_entry_root()
sys.source(file.path(QBD_ROOT, "R", "driver.R"), .GlobalEnv)
qbd_driver(QBD_ROOT, task="report")
