QBD_VERSION <- "2.0.0"

qbd_design <- function(cfg) {
  out <- expand.grid(n = cfg$N, phi = cfg$PHI, model = cfg$MODELS,
                     KEEP.OUT.ATTRS = FALSE, stringsAsFactors = FALSE)
  out$case_id <- sprintf("diag_%03d", seq_len(nrow(out)))
  out$replications <- as.integer(cfg$R_REPS)
  out[, c("case_id", "model", "n", "phi", "replications")]
}

qbd_options <- function(cfg, model) {
  ans <- list(); i <- 0L
  add <- function(source, alignment, bw, block) {
    i <<- i + 1L
    ans[[i]] <<- data.frame(option_id = sprintf("option_%03d", i),
      correction = source, alignment = alignment, bw_factor = bw,
      block_factor = block, stringsAsFactors = FALSE)
  }
  for (block in cfg$BLOCK_FACTORS) add("none", "none", NA_real_, block)
  for (align in cfg$ALIGNMENTS) for (bw in cfg$BW_FACTORS)
    for (block in cfg$BLOCK_FACTORS) add("estimated", align, bw, block)
  if (model == "normal") for (align in cfg$ALIGNMENTS)
    for (block in cfg$BLOCK_FACTORS) add("oracle_m", align, NA_real_, block)
  do.call(rbind, ans)
}

qbd_oracle_m <- function(phi, lags) {
  ans <- matrix(0, nrow(lags), 3L)
  for (i in seq_len(nrow(lags))) {
    times <- c(0, lags[i, ])
    correlation <- phi^abs(outer(times, times, "-"))
    for (j in 1:3) {
      other <- setdiff(1:3, j); a <- other[1L]; b <- other[2L]
      den <- sqrt((1 - correlation[a,j]^2) * (1 - correlation[b,j]^2))
      rho <- (correlation[a,b] - correlation[a,j] * correlation[b,j]) / den
      ans[i,j] <- asin(max(-1, min(1, rho))) / (2 * pi)
    }
  }
  colnames(ans) <- paste0("position", 1:3)
  ans
}

qbd_score <- function(raw, v, ctx, m, alignment) {
  t <- seq_len(ctx$N); u <- as.numeric(v <= .5) - .5
  ans <- raw
  for (j in 1:3) {
    shifts <- if (alignment == "base" || j == 1L) rep(0L, nrow(ctx$lags)) else ctx$lags[,j-1L]
    uk <- vapply(shifts, function(s) u[t + s], numeric(ctx$N))
    ans <- ans - sweep(uk, 2L, m[,j], "*")
  }
  ans
}

qbd_calibrate <- function(kappa, omega, n, z) {
  s <- sqrt(diag(omega))
  if (any(!is.finite(s) | s <= 0)) stop("Zero or invalid influence variance.")
  draws <- qbp_gaussian(omega, nrow(z), z)
  factor <- 6 / (2 * pi)^2 / (.5 * .5)^3
  observed <- c(energy = n * factor * sum(kappa^2),
                maximum = sqrt(n) * max(abs(kappa) / s))
  scaled <- abs(sweep(draws, 2L, s, "/"))
  maxima <- scaled[,1L]
  for (j in seq_len(ncol(scaled))[-1L]) maxima <- pmax(maxima,scaled[,j])
  simulated <- cbind(factor * rowSums(draws^2), maxima)
  p <- vapply(1:2, function(j)
    (1 + sum(qbp_ge(simulated[,j], observed[j]))) / (nrow(z) + 1), numeric(1))
  names(p) <- names(observed)
  list(p_value = p, statistic = observed, covered = abs(kappa) <= qnorm(.975) * s / sqrt(n))
}

qbd_replication <- function(case, cfg, seed, replication) {
  RNGkind("L'Ecuyer-CMRG", normal.kind = "Inversion", sample.kind = "Rejection")
  assign(".Random.seed", seed, .GlobalEnv)
  start <- proc.time()[["elapsed"]]
  notes <- character()
  out <- tryCatch(withCallingHandlers({
    y <- qbp_ar1(case$n, case$phi, case$model, cfg$AR_BURN)
    ties <- qbp_resolve_simulation_ties(y); y <- ties$values
    ctx <- qbp_context(case$n, cfg$H, .5)
    v <- qbp_rank_data(y, ctx)$v
    fits <- lapply(cfg$BW_FACTORS, function(b) qbp_influence(v, ctx, b))
    opt <- qbd_options(cfg, case$model); K <- nrow(opt); d <- nrow(ctx$lags)
    mtrue <- if (case$model == "normal") qbd_oracle_m(case$phi, ctx$lags) else NULL

    z <- matrix(rnorm(cfg$B_MULTIPLIER * d), cfg$B_MULTIPLIER, d)
    kappa <- fits[[1L]]$kappa; raw <- fits[[1L]]$raw
    p <- statistics <- matrix(NA_real_, K, 2L, dimnames = list(opt$option_id, c("energy", "maximum")))
    covered <- matrix(FALSE, K, d)
    omega <- array(NA_real_, dim = c(d, d, K))
    lengths <- blocks <- integer(K)
    scores <- new.env(parent = emptyenv())
    for (i in seq_len(K)) {
      key <- paste(opt$correction[i], opt$alignment[i], opt$bw_factor[i], sep = "_")
      if (!exists(key, scores, inherits = FALSE)) {
        if (opt$correction[i] == "none") score <- raw else {
          m <- if (opt$correction[i] == "oracle_m") mtrue else
            fits[[match(opt$bw_factor[i], cfg$BW_FACTORS)]]$mhat
          score <- qbd_score(raw, v, ctx, m, opt$alignment[i])
        }
        scores[[key]] <- score
      }
      covfit <- qbp_block_covariance(scores[[key]], case$n, opt$block_factor[i])
      omega[,,i] <- covfit$omega
      lengths[i] <- covfit$length; blocks[i] <- nrow(covfit$S)
      stat <- qbd_calibrate(kappa, covfit$omega, case$n, z)
      p[i,] <- stat$p_value; statistics[i,] <- stat$statistic
      covered[i,] <- stat$covered
    }
    list(kappa = kappa, p_values = p, statistics = statistics, omega = omega,
         covered = covered, block_lengths = lengths, blocks = blocks,
         mhat = lapply(fits, function(f) f$mhat),
         numerical_ties = ties[c("groups", "observations", "max_change")])
  }, warning = function(w) {
    notes <<- c(notes, conditionMessage(w)); invokeRestart("muffleWarning")
  }), error = function(e) list(error = conditionMessage(e)))
  out$status <- if (is.null(out$error)) "ok" else "error"
  out$warnings <- unique(notes)
  out$case_id <- case$case_id; out$replication <- as.integer(replication)
  out$elapsed_seconds <- unname(proc.time()[["elapsed"]] - start)
  out
}
