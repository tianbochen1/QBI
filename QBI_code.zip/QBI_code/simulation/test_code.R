qbd_entry_root <- function() {
  frames <- sys.frames()
  for (i in rev(seq_along(frames))) {
    of <- frames[[i]]$ofile
    if (!is.null(of) && length(of) == 1L && file.exists(of))
      return(dirname(normalizePath(of, winslash = "/")))
  }
  args <- commandArgs(trailingOnly = FALSE)
  filearg <- args[grepl("^--file=", args)]
  if (length(filearg)) {
    path <- sub("^--file=", "", filearg[1L])
    if (!file.exists(path)) path <- gsub("~+~", " ", path, fixed = TRUE)
    return(dirname(normalizePath(path, winslash = "/", mustWork = TRUE)))
  }
  if (file.exists("config.R")) return(normalizePath(getwd(), winslash = "/"))
  stop("Cannot locate the project directory. Set the working directory to the extracted code folder.")
}

root <- qbd_entry_root()
for (f in c("original/fn.R","original/engine.R","R/paths.R","R/supplement_functions.R",
            "R/supplement_engine.R","R/supplement_summary.R","R/driver.R"))
  sys.source(file.path(root,f),.GlobalEnv)
settings <- new.env(parent=.GlobalEnv);sys.source(file.path(root,"config.R"),settings)
check <- function(x,message) {
  if (!isTRUE(x)) stop("FAILED: ",message)
  cat("PASS:",message,"\n")
}
for (f in list.files(root,pattern="\\.R$",full.names=TRUE,recursive=TRUE)) parse(f)
check(TRUE,"all R files parse")
cfg <- settings$qbd_make_config("smoke")
ctx <- qbp_context(512L,3L,.5)
truth <- qbd_oracle_m(.7,ctx$lags)
check(all(qbd_oracle_m(0,ctx$lags)==0),"oracle correction is zero under independence")
check(max(abs(truth[,2L]))<1e-14,"Gaussian AR(1) endpoint signs are conditionally independent given the middle value")
set.seed(4921)
for (i in seq_len(nrow(ctx$lags))) for (j in 1:3) {
  times <- c(0,ctx$lags[i,]);rho <- .7^abs(outer(times,times,"-"))
  ab <- setdiff(1:3,j)
  conditional <- rho[ab,ab]-tcrossprod(rho[ab,j])
  draws <- matrix(rnorm(600000),ncol=2L) %*% chol(conditional)
  empirical <- mean(((draws[,1L]<=0)-.5)*((draws[,2L]<=0)-.5))
  check(abs(empirical-truth[i,j])<.0035,paste("oracle conditional-normal calculation",i,j))
}
RNGkind("L'Ecuyer-CMRG",normal.kind="Inversion",sample.kind="Rejection")
set.seed(271828);seed <- .Random.seed
case <- list(case_id="check",model="normal",n=512L,phi=.7,replications=1L)
result <- qbd_replication(case,cfg,seed,1L)
check(result$status=="ok","one full diagnostic replication finishes")
assign(".Random.seed",seed,.GlobalEnv)
y <- qbp_resolve_simulation_ties(qbp_ar1(512L,.7,"normal"))$values
oldcfg <- new.env(parent=.GlobalEnv);sys.source(file.path(root,"original","config.R"),oldcfg)
refcfg <- oldcfg$qbp_make_config("smoke")
refcfg$B_MULTIPLIER <- cfg$B_MULTIPLIER
reference <- qbp_dependent_tests(y,refcfg)$tests
opt <- qbd_options(cfg,"normal")
checks <- 0L
for (i in seq_len(nrow(reference))) {
  r <- reference[i,]
  if (r$correction=="corrected") {
    j <- which(opt$correction=="estimated" & opt$alignment=="base" &
      opt$bw_factor==r$bw_factor & opt$block_factor==r$block_factor)
  } else j <- which(opt$correction=="none" & opt$block_factor==r$block_factor)
  if (!length(j)) next
  k <- if (r$method=="QBP_median_energy") 1L else 2L
  check(result$p_values[j,k]==r$p_value &&
        abs(result$statistics[j,k]-r$statistic)<1e-12,"shared setting reproduces original inference")
  checks <- checks+1L
}
check(checks>=12L,"baseline comparison covers bandwidth and block-length settings")
v <- qbp_rank_data(y,ctx)$v;fit <- qbp_influence(v,ctx)
base <- qbd_score(fit$raw,v,ctx,fit$mhat,"base")
check(max(abs(base-fit$corrected))<1e-14,"base-time score matches the original implementation")
lagged <- qbd_score(fit$raw,v,ctx,fit$mhat,"lagged")
u <- (v<=.5)-.5;boundary <- numeric(nrow(ctx$lags))
for (i in seq_along(boundary)) for (j in 2:3) {
  shift <- ctx$lags[i,j-1L]
  boundary[i] <- boundary[i]+fit$mhat[i,j]*(sum(u[ctx$N+seq_len(shift)])-sum(u[seq_len(shift)]))
}
check(max(abs(colSums(base-lagged)-boundary))<1e-12,"two alignment sums differ only by the stated boundary terms")
check(!any(qbd_options(cfg,"t5")$correction=="oracle_m"),"Gaussian oracle is never applied to t5 innovations")

folder <- tempfile("qbd_validation_");dir.create(folder)
cfg$MAKE_PLOTS <- FALSE;cfg$N_CORES <- 1L;cfg$OUTPUT_DIR <- file.path(folder,"serial")
serial <- qbd_run(cfg,root)
cfg$N_CORES <- 8L;cfg$OUTPUT_DIR <- file.path(folder,"parallel")
parallel <- qbd_run(cfg,root)
load_summary <- function(path) {e<-new.env();load(file.path(path,"supplement_results.RData"),e);e$summaries}
a <- load_summary(serial);b <- load_summary(parallel)
fields <- setdiff(names(a),"runtime")
check(identical(a[fields],b[fields]),"serial and eight-worker summaries are identical")
check(all(a$completion$complete) && !nrow(a$errors),"all smoke diagnostic cases finish")
files <- list.files(file.path(parallel,"checkpoints"),recursive=TRUE,full.names=TRUE)
before <- tools::md5sum(files);qbd_run(cfg,root)
check(identical(before,tools::md5sum(files)),"resume keeps completed checkpoint bytes unchanged")

single <- cfg;single$RUN_CASES <- "diag_008";single$OUTPUT_DIR <- file.path(folder,"selected")
qbd_run(single,root)
s <- load_summary(single$OUTPUT_DIR)$rejection
expected <- a$rejection[a$rejection$case_id=="diag_008",,drop=FALSE]
rownames(expected) <- rownames(s) <- NULL
check(identical(s,expected),"case-only execution preserves its random streams")

records <- qbd_load_case(serial,"diag_001")
matrix_k <- do.call(rbind,lapply(records,function(x)x$kappa))
opt <- qbd_options(cfg,"normal")
ref <- which(opt$correction=="estimated" & opt$alignment=="base" & opt$bw_factor==1 & opt$block_factor==1)
summary_rows <- a$covariance[a$covariance$case_id=="diag_001" & a$covariance$option_id==opt$option_id[ref],]
check(max(abs(summary_rows$empirical_variance-diag(cov(matrix_k))))<1e-14,
      "streaming empirical variances equal direct sample variances")
for (i in c(1L,ref,nrow(opt))) {
  differences <- vapply(records,function(x)
    as.numeric(x$p_values[i,1L]<=cfg$ALPHA)-as.numeric(x$p_values[ref,1L]<=cfg$ALPHA),numeric(1))
  row <- a$paired_rejection_difference
  row <- row[row$case_id=="diag_001" & row$option_id==opt$option_id[i] & row$method=="energy",]
  check(abs(row$difference-mean(differences))<1e-14 && abs(row$paired_MCSE-sd(differences)/sqrt(length(differences)))<1e-14,
        "paired Monte Carlo error uses within-replication differences")
}
badpath <- files[1L];broken <- readRDS(badpath);saved <- broken$results
broken$results[[1L]]$status <- "error";broken$results[[1L]]$error <- "Injected validation failure"
saveRDS(broken,badpath,version=2)
qbd_run(cfg,root);restored <- readRDS(badpath)$results
for (i in seq_along(saved)) {saved[[i]]$elapsed_seconds<-NULL;restored[[i]]$elapsed_seconds<-NULL}
check(identical(saved,restored),"failed checkpoint records are recomputed with their original seeds")
qbd_plot(parallel)
check(length(list.files(file.path(parallel,"figures"),pattern="\\.pdf$"))>0L,"diagnostic figures are generated")

large <- settings$qbd_make_config("paper")
for (model in c("normal","t5")) {
  case$model <- model;case$n <- 8192L
  r <- qbd_replication(case,large,seed,1L)
  check(r$status=="ok" && all(is.finite(r$p_values)),paste("n=8192, 1999 draws, full diagnostic grid:",model))
}
report <- file.path(folder,"report")
qbd_make_report(file.path(root,"retained_results"),parallel,report)
check(file.exists(file.path(report,"original_rejection.csv")) &&
      file.exists(file.path(report,"supplement_rejection.csv")),"original and supplementary summaries are retained separately")
cat("All diagnostic validation checks passed.\n")
