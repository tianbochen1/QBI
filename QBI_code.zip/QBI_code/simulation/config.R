RUN_MODE <- "paper"
N_CORES <- 8L
RUN_ORIGINAL <- TRUE
RUN_SUPPLEMENT <- TRUE
ORIGINAL_PARTS <- 0:6
ORIGINAL_RESULTS_DIR <- file.path("results", paste0("original_", RUN_MODE))
ORIGINAL_OUTPUT_DIR <- file.path("results", paste0("original_", RUN_MODE))
SUPPLEMENT_OUTPUT_DIR <- file.path("results", paste0("supplement_", RUN_MODE))
REPORT_DIR <- file.path("results", paste0("report_", RUN_MODE))
RESUME <- TRUE
MAKE_PLOTS <- TRUE
RUN_CASES <- NULL
SUPPLEMENT_OVERRIDES <- list()

qbd_make_config <- function(mode = c("paper", "pilot", "smoke")) {
  mode <- match.arg(mode)
  ans <- list(MODE = mode, N_CORES = 8L, MASTER_SEED = 20260924L,
              H = 3L, ALPHA = .05, AR_BURN = 2000L,
              MODELS = c("normal", "t5"),
              BW_FACTORS = c(.5, 1, 2), BLOCK_FACTORS = c(1, 2, 4, 8),
              ALIGNMENTS = c("base", "lagged"),
              CHUNK_SIZE = 10L, RESUME = TRUE, MAKE_PLOTS = TRUE,
              RUN_CASES = NULL, OUTPUT_DIR = file.path("results", paste0("supplement_", mode)))
  if (mode == "paper") {
    ans$N <- c(512L, 1024L, 2048L, 4096L, 8192L)
    ans$PHI <- c(0, .4, .7)
    ans$R_REPS <- 2000L; ans$B_MULTIPLIER <- 1999L
  } else if (mode == "pilot") {
    ans$N <- c(512L, 2048L, 8192L); ans$PHI <- c(0, .7)
    ans$R_REPS <- 50L; ans$B_MULTIPLIER <- 399L
  } else {
    ans$N <- c(96L, 192L); ans$PHI <- c(0, .7)
    ans$R_REPS <- 2L; ans$B_MULTIPLIER <- 39L
    ans$CHUNK_SIZE <- 1L
    ans$BLOCK_FACTORS <- c(1, 2, 4)
  }
  ans
}

DIAG_CONFIG <- qbd_make_config(RUN_MODE)
DIAG_CONFIG$N_CORES <- as.integer(N_CORES)
DIAG_CONFIG$OUTPUT_DIR <- SUPPLEMENT_OUTPUT_DIR
DIAG_CONFIG$RESUME <- RESUME
DIAG_CONFIG$MAKE_PLOTS <- MAKE_PLOTS
DIAG_CONFIG$RUN_CASES <- RUN_CASES
if (length(SUPPLEMENT_OVERRIDES)) {
  if (is.null(names(SUPPLEMENT_OVERRIDES)) ||
      any(!names(SUPPLEMENT_OVERRIDES) %in% names(DIAG_CONFIG)))
    stop("SUPPLEMENT_OVERRIDES must name existing diagnostic settings.")
  DIAG_CONFIG[names(SUPPLEMENT_OVERRIDES)] <- SUPPLEMENT_OVERRIDES
}
