qbi_download <- function(url, dest, md5=NULL) {
  dir.create(dirname(dest), recursive=TRUE, showWarnings=FALSE)
  valid <- function(f) file.exists(f) && file.info(f)$size > 0 &&
    (is.null(md5) || identical(unname(tools::md5sum(f)), md5))
  if (valid(dest)) return(dest)
  old <- options(timeout=max(7200, getOption("timeout", 60)))
  on.exit(options(old))
  tmp <- paste0(dest, ".download")
  err <- "unknown download error"
  for (attempt in 1:3) {
    message("Downloading ", basename(dest), " (attempt ", attempt, ")")
    ok <- tryCatch({
      status <- withCallingHandlers(
        utils::download.file(url, tmp, mode="wb", method="libcurl", quiet=FALSE),
        warning=function(w) stop(conditionMessage(w)))
      if (!identical(as.integer(status), 0L)) stop("Nonzero download status")
      if (!valid(tmp)) stop("Incomplete file or checksum mismatch")
      TRUE
    }, error=function(e) {err <<- conditionMessage(e); FALSE})
    if (ok) {
      if (file.exists(dest)) unlink(dest)
      if (!file.rename(tmp, dest)) stop("Cannot move downloaded file to ", dest)
      return(dest)
    }
    if (file.exists(tmp)) unlink(tmp)
  }
  stop("Download failed: ", err, "\n", url)
}

qbi_download_cwru <- function(directory) {
  ids <- c(97:100, 109:112, 135:138)
  paths <- vapply(ids, function(id) {
    qbi_download(paste0("https://engineering.case.edu/sites/default/files/", id, ".mat"),
                 file.path(directory, paste0(id, ".mat")))
  }, character(1))
  invisible(paths)
}

qbi_download_sandyduck <- function(directory, runs=c("10011000", "10021000", "10031000"),
                                   sensors=c("u12", "u13", "u15")) {
  base <- "https://zenodo.org/records/8286465/files/"
  positions <- qbi_download(paste0(base, "SandyDuck_doffs.zip?download=1"),
    file.path(directory, "SandyDuck_doffs.zip"), "d5c13b17249b9ab08326f9b8cfd2c849")
  qbi_download(paste0(base, "README_sduck.txt?download=1"),
    file.path(directory, "README_sduck.txt"), "a3721364567cd554b964ce0b589346fe")
  utils::unzip(positions, exdir=file.path(directory, "positions"))
  wanted <- as.vector(outer(runs, sensors, paste, sep="."))
  have <- list.files(directory, recursive=TRUE, full.names=TRUE)
  missing <- setdiff(wanted, basename(have))
  for (month in unique(substr(missing, 1L, 2L))) {
    if (!month %in% c("09", "10")) stop("Only September and October 1997 are available.")
    name <- if (month=="09") "SandyDuck_Sep_timeseries.zip" else "SandyDuck_Oct_timeseries.zip"
    checksum <- if (month=="09") "7a2176bfb97aa0d9155828a3db2d39ae" else "e7cd7c797e69ea250ca4cb75cf505fcf"
    message(name, " is approximately 1.9 GB.")
    archive <- qbi_download(paste0(base, name, "?download=1"), file.path(directory, name), checksum)
    listing <- utils::unzip(archive, list=TRUE)$Name
    selected <- listing[basename(listing) %in% missing]
    if (length(selected)) utils::unzip(archive, files=selected, exdir=file.path(directory, "timeseries"))
  }
  have <- list.files(directory, recursive=TRUE, full.names=TRUE)
  missing <- setdiff(wanted, basename(have))
  if (length(missing)) stop("Missing records: ", paste(missing, collapse=", "))
  invisible(have[basename(have) %in% wanted])
}
