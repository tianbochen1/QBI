RUN_MODE <- "pilot"
RUN_PARTS <- 0:6
N_CORES <- 8L
MASTER_SEED <- 20260923L
CHUNK_SIZE <- 5L
OUTPUT_DIR <- file.path("results", RUN_MODE)
RESUME <- TRUE
STOP_ON_ERROR <- TRUE
MAKE_PLOTS <- TRUE
PARAM_OVERRIDES <- list()

qbp_make_config <- function(mode = c("pilot", "paper", "smoke")) {
  mode <- match.arg(mode)
  cfg <- list(RUN_MODE = mode, RUN_PARTS = 0:6, N_CORES = 8L,
              MASTER_SEED = 20260923L, CHUNK_SIZE = 5L,
              OUTPUT_DIR = file.path("results", mode), RESUME = TRUE,
              STOP_ON_ERROR = TRUE, MAKE_PLOTS = TRUE, ALPHA = 0.05, H = 3L,
              LEVELS = c(0.25, 0.5, 0.75), MIXED_LEVELS = c(1/6, 1/2, 5/6),
              M_VALUES = c(3L, 4L, 6L, 8L),
              EST_TUPLES = rbind(c(.25, .25, .25), c(.5, .5, .5),
                                c(.75, .75, .75), c(.25, .5, .75)),
              TUNING = data.frame(bw_factor = c(1, .5, 2, 1, 1),
                                  block_factor = c(1, 1, 1, .5, 2)),
              AR_BURN = 2000L, CONTAM_MAGNITUDE = 20, CONTAM_JITTER = .05,
              MARGINS = c("normal", "t5", "cauchy", "lognormal"),
              MODELS = c("linear", "even"))
  if (mode == "paper") {
    cfg$N_NULL <- c(512L, 1024L, 2048L)
    cfg$N_POWER <- c(512L, 2048L, 8192L)
    cfg$N_MIXED <- c(4096L, 16384L, 65536L)
    cfg$PHI <- c(0, .4, .7)
    cfg$THETA_POWER <- c(0, .3, .6, .9)
    cfg$THETA_MIXED <- c(0, .6, .9)
    cfg$THETA_EST <- c(0, .6, .9)
    cfg$THETA_INVARIANCE <- c(.6, .9)
    cfg$THETA_CONTAM <- c(0, .6, .9)
    cfg$EPSILON <- c(0, .01, .05)
    cfg$R_NULL <- 2000L; cfg$R_ALT <- 1000L
    cfg$R_EST <- 1000L; cfg$R_INVARIANCE <- 1000L
    cfg$B_PERMUTATION <- 999L; cfg$B_MULTIPLIER <- 1999L
  } else if (mode == "pilot") {
    cfg$N_NULL <- 512L; cfg$N_POWER <- 512L; cfg$N_MIXED <- 4096L
    cfg$PHI <- c(0, .7)
    cfg$THETA_POWER <- c(0, .6); cfg$THETA_MIXED <- c(0, .9)
    cfg$THETA_EST <- c(0, .6); cfg$THETA_INVARIANCE <- .6
    cfg$THETA_CONTAM <- c(0, .6); cfg$EPSILON <- c(0, .05)
    cfg$R_NULL <- 30L; cfg$R_ALT <- 30L
    cfg$R_EST <- 30L; cfg$R_INVARIANCE <- 10L
    cfg$B_PERMUTATION <- 199L; cfg$B_MULTIPLIER <- 399L
  } else {
    cfg$N_NULL <- 96L; cfg$N_POWER <- 96L; cfg$N_MIXED <- 128L
    cfg$PHI <- c(0, .7)
    cfg$THETA_POWER <- c(0, .6); cfg$THETA_MIXED <- c(0, .9)
    cfg$THETA_EST <- c(0, .6); cfg$THETA_INVARIANCE <- .6
    cfg$THETA_CONTAM <- c(0, .6); cfg$EPSILON <- c(0, .05)
    cfg$R_NULL <- 2L; cfg$R_ALT <- 2L; cfg$R_EST <- 2L; cfg$R_INVARIANCE <- 2L
    cfg$B_PERMUTATION <- 19L; cfg$B_MULTIPLIER <- 39L
    cfg$CHUNK_SIZE <- 1L
  }
  cfg
}

CONFIG <- qbp_make_config(RUN_MODE)
CONFIG$RUN_PARTS <- as.integer(RUN_PARTS)
CONFIG$N_CORES <- as.integer(N_CORES)
CONFIG$MASTER_SEED <- as.integer(MASTER_SEED)
CONFIG$CHUNK_SIZE <- as.integer(CHUNK_SIZE)
CONFIG$OUTPUT_DIR <- OUTPUT_DIR
CONFIG$RESUME <- RESUME
CONFIG$STOP_ON_ERROR <- STOP_ON_ERROR
CONFIG$MAKE_PLOTS <- MAKE_PLOTS
if (length(PARAM_OVERRIDES)) {
  if (is.null(names(PARAM_OVERRIDES)) || any(!names(PARAM_OVERRIDES) %in% names(CONFIG)))
    stop("PARAM_OVERRIDES must be a named list of existing CONFIG fields.")
  CONFIG[names(PARAM_OVERRIDES)] <- PARAM_OVERRIDES
}
