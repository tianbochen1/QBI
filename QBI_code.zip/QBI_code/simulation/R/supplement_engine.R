qbd_validate <- function(cfg) {
  integer_ok <- function(x) length(x) > 0L && all(is.finite(x) & x >= 1 & x == as.integer(x))
  stopifnot(integer_ok(c(cfg$N_CORES, cfg$CHUNK_SIZE, cfg$R_REPS, cfg$H,
                        cfg$N, cfg$B_MULTIPLIER, cfg$AR_BURN)), cfg$H >= 2L,
            all(cfg$MODELS %in% c("normal", "t5")), length(cfg$MODELS) > 0L,
            all(is.finite(cfg$PHI) & abs(cfg$PHI) < 1), length(cfg$PHI) > 0L,
            all(cfg$BW_FACTORS > 0), length(cfg$BW_FACTORS) > 0L,
            all(cfg$BLOCK_FACTORS > 0), length(cfg$BLOCK_FACTORS) > 0L,
            all(cfg$ALIGNMENTS %in% c("base", "lagged")), length(cfg$ALIGNMENTS) > 0L,
            cfg$ALPHA > 0, cfg$ALPHA < 1, all(cfg$N > cfg$H + 5L))
  for (field in c("N", "MODELS", "PHI", "BW_FACTORS", "BLOCK_FACTORS", "ALIGNMENTS"))
    if (anyDuplicated(cfg[[field]])) stop("Duplicated values in ", field)
  if (getRversion() < "3.6.0") stop("R >= 3.6.0 is required.")
  if (1 / (cfg$B_MULTIPLIER + 1) > cfg$ALPHA) stop("Too few multiplier draws.")
  for (n in cfg$N) {
    length_max <- ceiling(max(cfg$BLOCK_FACTORS) * ceiling(log(n)))
    if ((n - cfg$H) %/% length_max < 2L) stop("Too few blocks at n=", n)
  }
  invisible(TRUE)
}

qbd_fingerprint <- function(cfg, root) {
  cfg <- cfg[setdiff(names(cfg), c("N_CORES", "OUTPUT_DIR", "RESUME", "MAKE_PLOTS", "RUN_CASES"))]
  files <- file.path(root, c("original/fn.R", "original/engine.R",
                            "R/supplement_functions.R", "R/supplement_engine.R"))
  object <- list(config = cfg, code_md5 = unname(tools::md5sum(files)),
                 version = QBD_VERSION, R_version = as.character(getRversion()))
  tmp <- tempfile(); on.exit(unlink(tmp)); saveRDS(object, tmp, compress = FALSE, version = 2)
  list(hash = unname(tools::md5sum(tmp)), scientific = object)
}

qbd_jobs <- function(design, cfg, out, fingerprint) {
  RNGkind("L'Ecuyer-CMRG", normal.kind = "Inversion", sample.kind = "Rejection")
  set.seed(cfg$MASTER_SEED); case_seed <- .Random.seed
  jobs <- list(); j <- 0L
  if (!is.null(cfg$RUN_CASES) && any(!cfg$RUN_CASES %in% design$case_id))
    stop("RUN_CASES contains an unknown diagnostic case.")
  for (i in seq_len(nrow(design))) {
    case <- as.list(design[i,,drop = FALSE])
    if (is.null(cfg$RUN_CASES) || case$case_id %in% cfg$RUN_CASES) {
      seeds <- vector("list", case$replications); seed <- case_seed
      for (r in seq_len(case$replications)) {
        seeds[[r]] <- seed; seed <- parallel::nextRNGSubStream(seed)
      }
      chunks <- split(seq_len(case$replications), ceiling(seq_len(case$replications) / cfg$CHUNK_SIZE))
      for (reps in chunks) {
        j <- j + 1L
        jobs[[j]] <- list(case = case, reps = as.integer(reps), seeds = seeds[reps],
          fingerprint = fingerprint,
          path = file.path(out, "checkpoints", case$case_id,
                           sprintf("reps_%06d_%06d.rds", min(reps), max(reps))))
      }
    }
    case_seed <- parallel::nextRNGStream(case_seed)
  }
  jobs
}

qbd_work_job <- function(job, cfg) {
  old <- qbp_read_chunk(job$path)
  if (!is.null(old) && !identical(old$fingerprint, job$fingerprint)) stop("Checkpoint mismatch.")
  old_reps <- if (is.null(old)) integer() else vapply(old$results, function(x) x$replication, integer(1))
  results <- vector("list", length(job$reps))
  for (i in seq_along(job$reps)) {
    k <- match(job$reps[i], old_reps)
    if (!is.na(k) && identical(old$results[[k]]$status, "ok")) results[[i]] <- old$results[[k]] else
      results[[i]] <- qbd_replication(job$case, cfg, job$seeds[[i]], job$reps[i])
  }
  qbp_atomic_save(list(fingerprint = job$fingerprint, case_id = job$case$case_id, results = results),
                  job$path, replace = !is.null(old))
  bad <- which(vapply(results, function(x) x$status != "ok", logical(1)))
  error <- if (length(bad)) paste(job$case$case_id, "replication", results[[bad[1L]]]$replication,
                                 results[[bad[1L]]]$error) else ""
  list(failures = length(bad), warnings = sum(vapply(results, function(x) length(x$warnings), integer(1))),
       first_error = error)
}

qbd_run <- function(cfg, root) {
  qbd_validate(cfg)
  out <- qbd_path(cfg$OUTPUT_DIR, root)
  dir.create(out, recursive = TRUE, showWarnings = FALSE)
  out <- normalizePath(out, winslash = "/", mustWork = TRUE)
  design <- qbd_design(cfg); fingerprint <- qbd_fingerprint(cfg, root)
  path <- file.path(out, "manifest.rds")
  if (file.exists(path)) {
    meta <- readRDS(path)
    if (!identical(meta$fingerprint, fingerprint$hash))
      stop("Diagnostic configuration, core code or R version changed. Use a new supplement output directory.")
    if (!isTRUE(cfg$RESUME)) stop("Output exists. Use RESUME=TRUE or a new output directory.")
  } else {
    meta <- list(fingerprint = fingerprint$hash, scientific = fingerprint$scientific,
                 config = cfg, design = design, started = Sys.time(), session = sessionInfo(),
                 options = lapply(setNames(cfg$MODELS, cfg$MODELS), function(m) qbd_options(cfg, m)))
    qbp_atomic_save(meta, path)
    write.csv(design, file.path(out, "design.csv"), row.names = FALSE)
    for (m in cfg$MODELS) write.csv(meta$options[[m]], file.path(out, paste0("options_", m, ".csv")), row.names = FALSE)
    capture.output(sessionInfo(), file = file.path(out, "sessionInfo.txt"))
  }
  jobs <- qbd_jobs(design, cfg, out, fingerprint$hash)
  done <- vapply(jobs, function(j) qbp_chunk_complete(j$path, j$fingerprint, j$reps), logical(1))
  todo <- jobs[!done]
  cat(sprintf("Supplement %s: %d completed chunks, %d remaining; %d requested workers.\n",
              cfg$MODE, sum(done), length(todo), cfg$N_CORES))
  cat("Output:", out, "\n")
  if (cfg$MODE != "paper") cat("This is a code/pilot check, not a final Monte Carlo assessment.\n")
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1",
             VECLIB_MAXIMUM_THREADS = "1", BLIS_NUM_THREADS = "1")
  cl <- NULL
  close_workers <- function() {
    if (!is.null(cl)) { active <- cl; cl <<- NULL; parallel::stopCluster(active) }
  }
  on.exit(close_workers(), add = TRUE)
  if (length(todo) && cfg$N_CORES > 1L) {
    cl <- parallel::makePSOCKcluster(min(cfg$N_CORES, length(todo)), outfile = file.path(out, "workers.log"))
    parallel::clusterCall(cl, function(root) {
      for (f in c("original/fn.R", "original/engine.R", "R/supplement_functions.R", "R/supplement_engine.R"))
        sys.source(file.path(root, f), .GlobalEnv)
      NULL
    }, root)
  }
  start <- proc.time()[["elapsed"]]; finished <- 0L; failures <- 0L; warning_count <- 0L
  waves <- split(seq_along(todo), ceiling(seq_along(todo) / max(1L, 2L * cfg$N_CORES)))
  for (wave in waves) {
    ret <- if (is.null(cl)) lapply(todo[wave], qbd_work_job, cfg = cfg) else
      parallel::parLapplyLB(cl, todo[wave], qbd_work_job, cfg = cfg)
    finished <- finished + length(wave)
    failures <- failures + sum(vapply(ret, function(x) x$failures, integer(1)))
    warning_count <- warning_count + sum(vapply(ret, function(x) x$warnings, integer(1)))
    elapsed <- proc.time()[["elapsed"]] - start
    cat(sprintf("%s | chunks %d/%d | errors %d | warning records %d | %.1f min | rough ETA %.1f min\n",
                format(Sys.time(), "%H:%M:%S"), finished, length(todo), failures, warning_count,
                elapsed / 60, elapsed / finished * (length(todo) - finished) / 60))
    flush.console()
    if (failures) {
      close_workers(); qbd_summarize(out)
      msg <- vapply(ret, function(x) x$first_error, character(1))
      stop(msg[nzchar(msg)][1L], "\nSee ", file.path(out, "errors.csv"), call. = FALSE)
    }
  }
  close_workers()
  qbd_summarize(out)
  if (isTRUE(cfg$MAKE_PLOTS)) qbd_plot(out)
  invisible(out)
}
