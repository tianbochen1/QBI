qbp_plot_results <- function(directory) {
  file <- file.path(directory, "rejection.csv")
  if (!file.exists(file)) stop("Run the simulations or qbp_summarize() first.")
  if (file.info(file)$size < 5L) return(invisible(NULL))
  tab <- read.csv(file, stringsAsFactors = FALSE)
  if (!nrow(tab)) return(invisible(NULL))
  alpha <- readRDS(file.path(directory, "manifest.rds"))$config$ALPHA
  figures <- file.path(directory, "figures")
  dir.create(figures, recursive = TRUE, showWarnings = FALSE)
  colors <- c(QBP_median = "#7f7f7f", QBP_diagonal = "#0072B2", QBP_mixed = "#D55E00",
              QBP_mixed_max = "#CC79A7", Pairwise_rank = "#009E73", Ordinary_bispectrum = "#E69F00",
              QBP_ordered6 = "#000000")
  power <- tab[tab$part %in% c(2, 3, 6), , drop = FALSE]
  if (nrow(power)) {
    groups <- split(seq_len(nrow(power)), interaction(power$part, power$model, power$n,
                                                     power$epsilon, drop = TRUE))
    for (i in groups) {
      z <- power[i, , drop = FALSE]
      name <- sprintf("power_part%d_%s_n%d_eps%s.png", z$part[1], z$model[1], z$n[1], z$epsilon[1])
      png(file.path(figures, name), width = 1500, height = 1100, res = 180)
      tryCatch({
        par(mar = c(4.3, 4.4, 2.1, 1), las = 1)
        xr <- range(z$theta)
        if (diff(xr) == 0) xr <- xr + c(-.05, .05)
        plot(NA, xlim = xr, ylim = c(0, 1), xlab = expression(theta), ylab = "Rejection proportion",
             main = sprintf("%s, n = %d, contamination = %g", z$model[1], z$n[1], z$epsilon[1]))
        abline(h = alpha, lty = 3, col = "grey60")
        methods <- unique(z$method)
        for (j in seq_along(methods)) {
          a <- z[z$method == methods[j], ]; a <- a[order(a$theta), ]
          col <- colors[methods[j]]
          lines(a$theta, a$rejection_rate, type = "b", pch = 14L + j, col = col, lwd = 1.5)
          segments(a$theta, a$MC_lower, a$theta, a$MC_upper, col = adjustcolor(col, .5))
        }
        legend("topleft", methods, col = colors[methods], pch = 14L + seq_along(methods),
               lty = 1, bty = "n", cex = .73)
      }, finally = dev.off())
    }
  }
  null <- tab[tab$part == 1 & tab$bw_factor == 1 & tab$block_factor == 1, , drop = FALSE]
  if (nrow(null)) {
    groups <- split(seq_len(nrow(null)), interaction(null$model, null$n, null$method, drop = TRUE))
    for (i in groups) {
      z <- null[i, ]; name <- sprintf("null_%s_n%d_%s.png", z$model[1], z$n[1], z$method[1])
      png(file.path(figures, name), width = 1350, height = 1000, res = 180)
      tryCatch({
        par(mar = c(4.3, 4.4, 2.1, 1), las = 1)
        yr <- c(0, max(.1, z$MC_upper))
        plot(NA, xlim = c(0, max(.1, z$phi)), ylim = yr, xlab = expression(phi),
             ylab = "Rejection proportion", main = sprintf("%s innovations, n = %d", z$model[1], z$n[1]))
        abline(h = alpha, lty = 3, col = "grey50")
        for (j in 1:2) {
          label <- c("corrected", "uncorrected")[j]
          a <- z[z$correction == label, ]; a <- a[order(a$phi), ]
          color <- c("#0072B2", "#D55E00")[j]
          lines(a$phi, a$rejection_rate, type = "b", pch = 15L + j, col = color, lwd = 1.5)
          segments(a$phi, a$MC_lower, a$phi, a$MC_upper, col = color)
        }
        legend("topleft", c("Corrected", "Uncorrected"), col = c("#0072B2", "#D55E00"),
               lty = 1, pch = c(16, 17), bty = "n")
      }, finally = dev.off())
    }
  }
  cat("Figures saved to", figures, "\n")
  invisible(figures)
}
