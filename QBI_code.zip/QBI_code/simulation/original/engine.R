qbp_design <- function(cfg) {
  rows <- list(); id <- 0L
  add <- function(part, model, n, theta = NA_real_, phi = NA_real_,
                  margin = "uniform", epsilon = 0) {
    id <<- id + 1L
    null <- part %in% c(0L, 1L) || (!is.na(theta) && theta == 0)
    R <- if (part == 4L) cfg$R_EST else if (part == 5L) cfg$R_INVARIANCE else
      if (null) cfg$R_NULL else cfg$R_ALT
    rows[[id]] <<- data.frame(case_id = sprintf("case_%03d", id), part = part,
                             model = model, n = as.integer(n), theta = theta, phi = phi,
                             margin = margin, epsilon = epsilon, null_design = null,
                             replications = as.integer(R), stringsAsFactors = FALSE)
  }
  for (n in cfg$N_NULL) for (m in cfg$MARGINS) add(0L, "iid", n, margin = m)
  for (n in cfg$N_NULL) for (model in c("normal", "t5")) for (phi in cfg$PHI)
    add(1L, model, n, phi = phi, margin = "AR1")
  for (n in cfg$N_POWER) for (model in cfg$MODELS) for (theta in cfg$THETA_POWER)
    add(2L, model, n, theta)
  for (n in cfg$N_MIXED) for (theta in cfg$THETA_MIXED) add(3L, "mixed", n, theta)
  for (n in cfg$N_POWER) for (model in cfg$MODELS) for (theta in cfg$THETA_EST)
    add(4L, model, n, theta)
  for (n in cfg$N_POWER) for (model in cfg$MODELS) for (theta in cfg$THETA_INVARIANCE)
    add(5L, model, n, theta, margin = "transformed")
  for (n in cfg$N_POWER) for (model in cfg$MODELS) for (theta in cfg$THETA_CONTAM)
    for (epsilon in cfg$EPSILON) add(6L, model, n, theta, epsilon = epsilon)
  do.call(rbind, rows)
}

qbp_validate_config <- function(cfg) {
  positive_integer <- function(x) all(is.finite(x) & x >= 1 & x == as.integer(x))
  stopifnot(positive_integer(c(cfg$N_CORES, cfg$CHUNK_SIZE, cfg$R_NULL, cfg$R_ALT,
                              cfg$R_EST, cfg$R_INVARIANCE, cfg$B_PERMUTATION,
                              cfg$B_MULTIPLIER)), cfg$ALPHA > 0, cfg$ALPHA < 1,
            all(cfg$RUN_PARTS %in% 0:6), length(cfg$RUN_PARTS) > 0L,
            all(abs(c(cfg$THETA_POWER, cfg$THETA_MIXED, cfg$THETA_EST,
                      cfg$THETA_INVARIANCE, cfg$THETA_CONTAM)) < 1),
            all(abs(cfg$PHI) < 1), all(cfg$EPSILON >= 0 & cfg$EPSILON <= 1),
            all(cfg$N_NULL > cfg$H + 5L), all(cfg$N_POWER > max(cfg$H, cfg$M_VALUES) + 5L),
            all(cfg$N_MIXED > cfg$H + 5L))
  if (getRversion() < "3.6.0") stop("R >= 3.6.0 is required for the specified RNG.")
  if (1 / (cfg$B_PERMUTATION + 1) > cfg$ALPHA)
    stop("Too few permutations to attain the requested significance level.")
  invisible(TRUE)
}

qbp_atomic_save <- function(object, file, replace = FALSE) {
  dir.create(dirname(file), recursive = TRUE, showWarnings = FALSE)
  tmp <- tempfile(pattern = "checkpoint_", tmpdir = dirname(file), fileext = ".tmp")
  on.exit(unlink(tmp), add = TRUE)
  saveRDS(object, tmp, compress = "gzip", version = 2)
  if (file.exists(file)) {
    if (!replace) return(invisible(file))
    if (!file.remove(file)) stop("Cannot replace checkpoint: ", file)
  }
  if (!file.rename(tmp, file)) stop("Cannot finalize checkpoint: ", file)
  invisible(file)
}

qbp_fingerprint <- function(cfg, root) {
  scientific <- cfg[setdiff(names(cfg), c("RUN_PARTS", "N_CORES", "OUTPUT_DIR",
                                        "RESUME", "STOP_ON_ERROR", "MAKE_PLOTS"))]
  core <- file.path(root, c("fn.R", "engine.R"))
  object <- list(config = scientific, code_md5 = unname(tools::md5sum(core)),
                 version = QBP_CODE_VERSION, R_version = as.character(getRversion()))
  tmp <- tempfile(fileext = ".rds"); on.exit(unlink(tmp))
  saveRDS(object, tmp, compress = FALSE, version = 2)
  list(hash = unname(tools::md5sum(tmp)), scientific = object)
}

qbp_compatible_tie_patch <- function(old, current, root) {
  path <- file.path(root, "resume_compatibility.csv")
  if (!file.exists(path)) return(FALSE)
  a <- old$scientific; b <- current$scientific
  if (!identical(a$config, b$config) || !identical(a$R_version, b$R_version) ||
      !identical(a$version, "1.0.0") || !identical(b$version, "1.0.1")) return(FALSE)
  allowed <- read.csv(path, stringsAsFactors = FALSE, colClasses = "character")
  needed <- c("old_fn", "old_engine", "new_fn", "new_engine")
  if (!all(needed %in% names(allowed)) || length(a$code_md5) != 2L ||
      length(b$code_md5) != 2L) return(FALSE)
  any(allowed$old_fn == a$code_md5[1L] & allowed$old_engine == a$code_md5[2L] &
        allowed$new_fn == b$code_md5[1L] & allowed$new_engine == b$code_md5[2L])
}

qbp_read_chunk <- function(path) {
  if (!file.exists(path)) return(NULL)
  tryCatch(readRDS(path), error = function(e)
    stop("Unreadable checkpoint: ", path, ". Move this file aside before resuming."))
}

qbp_chunk_complete <- function(path, fingerprint, reps) {
  x <- qbp_read_chunk(path)
  if (is.null(x)) return(FALSE)
  if (!identical(x$fingerprint, fingerprint)) stop("Checkpoint fingerprint mismatch: ", path)
  done <- vapply(x$results, function(r) r$replication, integer(1))
  ok <- vapply(x$results, function(r) identical(r$status, "ok"), logical(1))
  all(reps %in% done[ok])
}

qbp_build_jobs <- function(design, cfg, directory, fingerprint) {
  RNGkind("L'Ecuyer-CMRG", normal.kind = "Inversion", sample.kind = "Rejection")
  set.seed(cfg$MASTER_SEED)
  case_seed <- get(".Random.seed", .GlobalEnv)
  jobs <- list(); j <- 0L
  for (i in seq_len(nrow(design))) {
    case <- as.list(design[i, , drop = FALSE])
    rep_seed <- case_seed
    if (case$part %in% cfg$RUN_PARTS) {
      seeds <- vector("list", case$replications)
      for (r in seq_len(case$replications)) {
        seeds[[r]] <- rep_seed
        rep_seed <- parallel::nextRNGSubStream(rep_seed)
      }
      chunks <- split(seq_len(case$replications),
                      ceiling(seq_len(case$replications) / cfg$CHUNK_SIZE))
      for (reps in chunks) {
        j <- j + 1L
        path <- file.path(directory, "checkpoints", paste0("part", case$part), case$case_id,
                          sprintf("reps_%06d_%06d.rds", min(reps), max(reps)))
        jobs[[j]] <- list(case = case, reps = as.integer(reps), seeds = seeds[reps],
                          path = path, fingerprint = fingerprint)
      }
    }
    case_seed <- parallel::nextRNGStream(case_seed)
  }
  jobs
}

qbp_work_chunk <- function(job, cfg) {
  old <- qbp_read_chunk(job$path)
  if (!is.null(old) && !identical(old$fingerprint, job$fingerprint))
    stop("Checkpoint fingerprint mismatch.")
  results <- vector("list", length(job$reps))
  old_reps <- if (is.null(old)) integer() else
    vapply(old$results, function(x) x$replication, integer(1))
  for (i in seq_along(job$reps)) {
    take <- match(job$reps[i], old_reps)
    if (!is.na(take) && identical(old$results[[take]]$status, "ok")) {
      results[[i]] <- old$results[[take]]
    } else results[[i]] <- qbp_one_replication(job$case, cfg, job$seeds[[i]], job$reps[i])
  }
  qbp_atomic_save(list(fingerprint = job$fingerprint, case_id = job$case$case_id,
                      results = results), job$path, replace = !is.null(old))
  failures <- sum(vapply(results, function(x) x$status != "ok", logical(1)))
  bad <- which(vapply(results, function(x) x$status != "ok", logical(1)))
  first_error <- if (length(bad)) {
    r <- results[[bad[1L]]]
    sprintf("%s, replication %d: %s", r$case$case_id, r$replication, r$error)
  } else ""
  list(path = job$path, failures = failures, completed = length(results) - failures,
       first_error = first_error)
}

qbp_is_absolute <- function(path) grepl("^(/|[A-Za-z]:|\\\\)", path)

qbp_run <- function(cfg, root = getwd(), summarize = TRUE) {
  qbp_validate_config(cfg)
  root <- normalizePath(root, winslash = "/", mustWork = TRUE)
  output <- if (qbp_is_absolute(cfg$OUTPUT_DIR)) cfg$OUTPUT_DIR else file.path(root, cfg$OUTPUT_DIR)
  dir.create(output, recursive = TRUE, showWarnings = FALSE)
  output <- normalizePath(output, winslash = "/", mustWork = TRUE)
  design <- qbp_design(cfg); fingerprint <- qbp_fingerprint(cfg, root)
  meta_path <- file.path(output, "manifest.rds")
  if (file.exists(meta_path)) {
    meta <- readRDS(meta_path)
    if (!isTRUE(cfg$RESUME)) stop("Output already exists. Use RESUME=TRUE or a new OUTPUT_DIR.")
    if (!identical(meta$fingerprint, fingerprint$hash)) {
      if (!qbp_compatible_tie_patch(meta, fingerprint, root))
        stop("Configuration, core code, or R version changed. Use a new OUTPUT_DIR. ",
             "Changing N_CORES or RUN_PARTS alone is allowed.")
      qbp_atomic_save(list(original_fingerprint = meta$fingerprint,
                          patched_fingerprint = fingerprint$hash,
                          patched_scientific = fingerprint$scientific,
                          reason = "Numerical ties in simulated continuous data; successful old replications unchanged.",
                          applied = Sys.time()), file.path(output, "numerical_tie_patch.rds"))
      fingerprint$hash <- meta$fingerprint
      cat("Applying compatible 1.0.1 numerical-tie patch; keeping completed replications.\n")
    }
  } else {
    meta <- list(fingerprint = fingerprint$hash, scientific = fingerprint$scientific,
                 config = cfg, design = design, session = sessionInfo(), started = Sys.time())
    qbp_atomic_save(meta, meta_path)
    write.csv(design, file.path(output, "design.csv"), row.names = FALSE)
    capture.output(sessionInfo(), file = file.path(output, "sessionInfo.txt"))
  }
  jobs <- qbp_build_jobs(design, cfg, output, fingerprint$hash)
  finished <- vapply(jobs, function(j) qbp_chunk_complete(j$path, j$fingerprint, j$reps), logical(1))
  todo <- jobs[!finished]
  cat(sprintf("Mode: %s | parts: %s | workers: %d\n", cfg$RUN_MODE,
              paste(cfg$RUN_PARTS, collapse = ","), cfg$N_CORES))
  cat(sprintf("Cases selected: %d | completed chunks: %d | remaining chunks: %d\n",
              sum(design$part %in% cfg$RUN_PARTS), sum(finished), length(todo)))
  cat("Output:", output, "\n")
  if (cfg$RUN_MODE != "paper") cat("This profile is for code/pilot checks, not final Monte Carlo conclusions.\n")
  Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1",
             VECLIB_MAXIMUM_THREADS = "1", BLIS_NUM_THREADS = "1")
  cl <- NULL
  close_workers <- function() {
    if (!is.null(cl)) {
      active <- cl; cl <<- NULL
      tryCatch(parallel::stopCluster(active), error = function(e)
        warning("Worker shutdown: ", conditionMessage(e), call. = FALSE))
    }
    invisible(NULL)
  }
  on.exit(close_workers(), add = TRUE)
  if (length(todo) && cfg$N_CORES > 1L) {
    cores <- min(cfg$N_CORES, length(todo))
    cl <- parallel::makePSOCKcluster(cores, outfile = file.path(output, "workers.log"))
    parallel::clusterCall(cl, function(root) {
      source(file.path(root, "fn.R"), local = .GlobalEnv)
      source(file.path(root, "engine.R"), local = .GlobalEnv)
      NULL
    }, root)
  }
  if (length(todo)) {
    wave_size <- max(1L, 2L * cfg$N_CORES)
    waves <- split(seq_along(todo), ceiling(seq_along(todo) / wave_size))
    completed <- 0L; failed <- 0L; start <- proc.time()[["elapsed"]]
    for (wave in waves) {
      ret <- if (is.null(cl)) lapply(todo[wave], qbp_work_chunk, cfg = cfg) else
        parallel::parLapplyLB(cl, todo[wave], qbp_work_chunk, cfg = cfg)
      completed <- completed + length(wave)
      failed <- failed + sum(vapply(ret, function(x) x$failures, integer(1)))
      elapsed <- proc.time()[["elapsed"]] - start
      eta <- elapsed / completed * (length(todo) - completed)
      cat(sprintf("%s | chunks %d/%d | failures %d | elapsed %.1f min | rough ETA %.1f min\n",
                  format(Sys.time(), "%H:%M:%S"), completed, length(todo), failed, elapsed / 60, eta / 60))
      flush.console()
      if (failed > 0L && isTRUE(cfg$STOP_ON_ERROR)) {
        close_workers()
        if (summarize) {
          source(file.path(root, "summarize_results.R"), local = .GlobalEnv)
          qbp_summarize(output)
        }
        messages <- vapply(ret, function(x) x$first_error, character(1))
        first <- messages[nzchar(messages)][1L]
        stop("A replication failed: ", first, "\nDetails: ",
             file.path(output, "errors.csv"), call. = FALSE)
      }
    }
  }
  close_workers()
  if (summarize) {
    source(file.path(root, "summarize_results.R"), local = .GlobalEnv)
    qbp_summarize(output)
    if (isTRUE(cfg$MAKE_PLOTS)) {
      source(file.path(root, "plot_results.R"), local = .GlobalEnv)
      qbp_plot_results(output)
    }
  }
  invisible(output)
}
