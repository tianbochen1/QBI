args <- commandArgs(FALSE)
filearg <- args[grepl("^--file=", args)]
ofile <- tryCatch(sys.frame(1)$ofile, error=function(e) NULL)
path <- if (!is.null(ofile)) ofile else if (length(filearg)) sub("^--file=", "", filearg[1L]) else "test_applications.R"
root <- dirname(normalizePath(path, mustWork=TRUE))
options(qbp.skip.autorun=TRUE)
for (dataset in c("CWRU", "SandyDuck")) {
  source(file.path(root, paste0("QBI_", dataset, ".R")))
  cfg <- CONFIG
  cfg$WORKERS <- 2L
  cfg$B_PRIMARY <- cfg$B_SENSITIVITY <- 99L
  cfg$MIN_N <- 512L
  cfg$MIN_BLOCKS <- 8L
  cfg$BLOCK_LENGTHS <- c(16L, 32L)
  cfg$PRIMARY_BLOCK <- 16L
  cfg$LAG_POINTS <- 1:3
  cfg$MAP_H <- 4L
  cfg$MAP_H_VALUES <- 4L
  cfg$FREQ_GRID <- 9L
  cfg$MAKE_PLOTS <- FALSE
  cfg$RUN_EXTENDED_LAGS <- FALSE
  cfg$RUN_CALIBRATION <- FALSE
  cc <- qs_stage_cfg(cfg, "primary")
  set.seed(761L)
  y <- as.numeric(arima.sim(list(ar=.4), n=1024L))
  fit <- qa_fit(y, cc)
  transformed <- qa_fit(exp(y/10), cc)
  idx <- fit$index$type=="rank3"
  stopifnot(identical(fit$index$estimate[idx], transformed$index$estimate[idx]))
  infer <- qa_infer(fit, cc, 918L)
  stopifnot(all(is.finite(infer$tests$p_value)),
            all(infer$tests$p_value >= 1/(cc$B+1)),
            all(infer$tests$p_value <= 1))
  tied <- qa_infer(qa_fit(round(y, 1), cc), cc, 918L)
  stopifnot(all(is.na(tied$tests$p_value[tied$tests$method!="Ordinary_bispectrum"])))
  folder <- tempfile(paste0("qbi_", dataset, "_"))
  dir.create(folder)
  tasks <- lapply(1:2, function(i) {
    z <- if (i==1L) y else rev(y)
    job <- list(id=paste0("segment_", i), y=z, raw_y=z, fs=2,
                time=seq_along(z)/2, time_label="Time (seconds)", metadata=list())
    list(job=job, cfg=cc, stage="primary", folder=file.path(folder, paste0("parallel_", i)),
         seed=qs_seed(job$id, cfg), fingerprint=paste0("test_", i))
  })
  parallel_result <- qs_parallel(tasks, qs_worker, cfg, file.path(folder, "parallel"))
  stopifnot(all(vapply(parallel_result, function(x) x$status=="ok", logical(1))))
  cfg$WORKERS <- 1L
  for (i in seq_along(tasks)) {
    task <- tasks[[i]]
    cached <- qs_worker(task, cfg)
    stopifnot(cached$cached, identical(cached$tests, parallel_result[[i]]$tests))
    task$folder <- file.path(folder, paste0("serial_", i))
    serial <- qs_worker(task, cfg)
    stopifnot(serial$status=="ok", identical(serial$tests, parallel_result[[i]]$tests))
  }
  cat("PASS:", dataset, "rank invariance, tie policy, multipliers, two-worker agreement and resume\n")
}
