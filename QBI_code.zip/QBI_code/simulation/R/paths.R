qbd_script_root <- function() {
  frames <- sys.frames()
  for (i in rev(seq_along(frames))) {
    of <- frames[[i]]$ofile
    if (!is.null(of) && length(of) == 1L && file.exists(of))
      return(dirname(normalizePath(of, winslash = "/", mustWork = TRUE)))
  }
  args <- commandArgs(trailingOnly = FALSE)
  arg <- args[grepl("^--file=", args)]
  if (length(arg)) {
    path <- sub("^--file=", "", arg[1L])
    if (!file.exists(path)) path <- gsub("~+~", " ", path, fixed = TRUE)
    return(dirname(normalizePath(path, winslash = "/", mustWork = TRUE)))
  }
  if (file.exists("config.R")) return(normalizePath(getwd(), winslash = "/"))
  stop("Set the working directory to the complete project folder.")
}
qbd_path <- function(path, root) {
  if (grepl("^(/|[A-Za-z]:|\\\\)", path)) path else file.path(root, path)
}
