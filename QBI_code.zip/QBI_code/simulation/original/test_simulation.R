args <- commandArgs(trailingOnly = FALSE)
filearg <- args[grepl("^--file=", args)]
ofile <- tryCatch(sys.frame(1)$ofile, error = function(e) NULL)
script_path <- if (length(filearg)) sub("^--file=", "", filearg[1L]) else NULL
if (!is.null(script_path) && !file.exists(script_path))
  script_path <- gsub("~+~", " ", script_path, fixed = TRUE)
root <- if (!is.null(ofile)) dirname(normalizePath(ofile)) else if (!is.null(script_path))
  dirname(normalizePath(script_path)) else getwd()
source(file.path(root, "fn.R"))
source(file.path(root, "config.R"))
source(file.path(root, "engine.R"))
source(file.path(root, "summarize_results.R"))

check <- function(ok, label) {
  if (!isTRUE(ok)) stop("FAILED: ", label)
  cat("PASS:", label, "\n")
}

for (f in list.files(root, pattern = "\\.R$", full.names = TRUE)) parse(f)
check(TRUE, "all R files parse")
RNGkind("L'Ecuyer-CMRG", normal.kind = "Inversion", sample.kind = "Rejection")
set.seed(20260923L)
failure_seed <- .Random.seed
for (i in 1:4) failure_seed <- parallel::nextRNGStream(failure_seed)
for (i in 1:881) failure_seed <- parallel::nextRNGSubStream(failure_seed)
failure_cfg <- qbp_make_config("paper")
failure_case <- as.list(qbp_design(failure_cfg)[5L, , drop = FALSE])
fixed <- qbp_one_replication(failure_case, failure_cfg, failure_seed, 882L)
check(fixed$status == "ok" && fixed$numerical_ties$observations == 2L &&
        fixed$numerical_ties$max_change < 1e-12,
      "reported case_005 replication 882 completes with 999 permutations")
plain <- seq(.01, .99, length.out = 100L); rng_before <- .Random.seed
check(identical(qbp_resolve_simulation_ties(plain)$values, plain) &&
        identical(rng_before, .Random.seed), "distinct samples and their RNG state are unchanged")
ties <- c(.1, .2, .2, .5, .5, .5, .8, .9)
resolved <- qbp_resolve_simulation_ties(ties, c(0, 1))$values
check(!anyDuplicated(resolved) && all(outer(resolved, resolved, "<")[outer(ties, ties, "<")]),
      "numerical tie resolution preserves all originally strict order comparisons")
set.seed(314159)
n <- 96L; H <- 3L; ctx <- qbp_context(n, H)
v <- qbp_block_uniform(n, .6, "even")
rd <- qbp_rank_data(v, ctx)
U <- sweep(outer(rd$v, ctx$levels, "<="), 2L, ctx$levels, "-")
direct <- vapply(seq_len(nrow(ctx$index)), function(j) {
  a <- ctx$index[j, ]; t <- seq_len(ctx$N)
  mean(U[t, a$a] * U[t + a$h, a$b] * U[t + a$k, a$c])
}, numeric(1))
km <- qbp_moments(rd$category, ctx)
check(max(abs(as.vector(t(km)) - direct)) < 1e-14,
      "contingency-table moments equal direct products")

fit <- qbp_influence(rd$v, ctx)
check(max(abs(fit$kappa - direct)) < 1e-14, "influence-function moments use the same estimator")
t <- seq_len(ctx$N)
for (j in c(1L, 14L, 27L, 50L, 81L)) {
  a <- ctx$index[j, ]; r <- c(0, a$h, a$k); tau <- c(a$tau1, a$tau2, a$tau3)
  ui <- cbind(U[t, a$a], U[t + a$h, a$b], U[t + a$k, a$c])
  for (slot in 1:3) {
    w <- pmax(1 - abs(rd$v[t + r[slot]] - tau[slot]) / n^(-1/6), 0)
    expected <- sum(w * apply(ui[, -slot, drop = FALSE], 1L, prod)) / sum(w)
    check(abs(expected - fit$mhat[j, slot]) < 1e-14, paste("marginal correction", j, slot))
  }
}

omega <- qbp_block_covariance(fit$corrected, n)$omega
check(min(eigen(omega, symmetric = TRUE, only.values = TRUE)$values) > -1e-12,
      "block covariance is positive semidefinite")

grid <- seq(0, 2*pi, length.out = 2*H + 2L)[- (2*H + 2L)]
frequencies <- as.matrix(expand.grid(w1 = grid, w2 = grid))
total <- 0
for (j in seq_len(nrow(ctx$tuples))) {
  cfs <- qbp_coefficients(km, ctx, ctx$tau[j, ])
  values <- as.numeric(cfs$coefficient) %*%
    exp(-1i * (outer(cfs$h, frequencies[, 1L]) + outer(cfs$k, frequencies[, 2L]))) / (2*pi)^2
  numerical <- (2*pi)^2 * mean(Mod(values)^2)
  total <- total + numerical / ctx$v3[j]
  separated <- qbp_ise(cfs$coefficient, cfs$h, cfs$k)
  check(abs(numerical - separated["ise"]) < 1e-14,
        paste("Parseval identity, tuple", j))
  check(abs((2*pi)^2 * mean(Re(values)^2) - separated["ise_real"]) < 1e-14 &&
          abs((2*pi)^2 * mean(Im(values)^2) - separated["ise_imag"]) < 1e-14,
        paste("real/imaginary ISE, tuple", j))
}
check(abs(n * total - qbp_rank_statistics(rd$category, ctx)["QBP_mixed"]) < 1e-11,
      "integrated test includes the six-permutation factor")

Gq <- qbp_G(c(.25, .5, .75), "even")
check(abs(Gq[2L]) < 1e-12 && Gq[1L] > 0 && abs(Gq[1L] + Gq[3L]) < 1e-12,
      "even loading cancels at the median")
gg <- sapply(1:3, function(j) qbp_G(c(1/6, 1/2, 5/6), "mixed", j))
check(max(abs(gg - diag(diag(gg)))) < 1e-12 && all(diag(gg) > 0),
      "mixed loading supports are disjoint")

set.seed(2718)
big <- qbp_block_uniform(200000L, .8, "linear")
u <- (big <= .5) - .5; t <- seq_len(length(u) - 2L)
empirical <- mean(u[t] * u[t + 1L] * u[t + 2L])
truth <- 2 * .8 / 7 * .25^3
check(abs(empirical - truth) < 8 * .125 / sqrt(length(t)),
      "stationary block generator matches its analytic third moment")
check(abs(mean(u[t] * u[t + 1L])) < .006,
      "stationary block generator has negligible empirical pair covariance")

cfg <- qbp_make_config("smoke")
cfg$CHUNK_SIZE <- 2L
cfg$MAKE_PLOTS <- FALSE
inv <- qbp_invariance(v, cfg)$invariance
check(all(unlist(inv[, -1L, drop = FALSE]) <= 1e-12),
      "normal/t5/Cauchy transformations preserve ranks, corrections, covariance and p-values")

test_root <- tempfile("qbp_validation_"); dir.create(test_root)
cfg$N_CORES <- 1L; cfg$OUTPUT_DIR <- file.path(test_root, "serial")
serial <- qbp_run(cfg, root)
cfg$N_CORES <- 8L; cfg$OUTPUT_DIR <- file.path(test_root, "parallel")
parallel <- qbp_run(cfg, root)
a <- qbp_collect(serial); b <- qbp_collect(parallel)
fields <- c("tests", "covariance", "estimation", "invariance", "errors")
check(isTRUE(all.equal(a[fields], b[fields], tolerance = 0, check.attributes = TRUE)),
      "one-worker and eight-worker numerical results are identical")
check(nrow(a$errors) == 0L && all(0:6 %in% a$runtime$part),
      "all seven simulation modules finish without errors")

files <- list.files(file.path(parallel, "checkpoints"), recursive = TRUE, full.names = TRUE)
before <- file.info(files)$mtime
qbp_run(cfg, root)
check(identical(before, file.info(files)$mtime), "resuming leaves completed checkpoints unchanged")

cfg$RUN_PARTS <- 3L; cfg$N_CORES <- 2L
cfg$OUTPUT_DIR <- file.path(test_root, "selected_part")
selected <- qbp_run(cfg, root)
s <- qbp_collect(selected)$tests
expected <- a$tests[a$tests$part == 3L, , drop = FALSE]
rownames(s) <- rownames(expected) <- NULL
check(isTRUE(all.equal(s, expected, tolerance = 0)),
      "running one module separately retains the same random streams")

source(file.path(root, "plot_results.R"))
qbp_plot_results(parallel)
check(length(list.files(file.path(parallel, "figures"), pattern = "\\.png$")) > 0,
      "summary figures are generated")
cfg$RUN_PARTS <- 4L; cfg$MAKE_PLOTS <- TRUE
cfg$OUTPUT_DIR <- file.path(test_root, "estimation_only")
est_only <- qbp_run(cfg, root)
check(file.exists(file.path(est_only, "simulation_results.RData")) &&
        nrow(qbp_collect(est_only)$estimation) > 0,
      "estimation-only runs handle an empty rejection table")
cat("All validation checks passed. Temporary validation output:", test_root, "\n")
