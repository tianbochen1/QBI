qbd_make_report <- function(original_dir, supplement_dir, report_dir) {
  dir.create(report_dir, recursive = TRUE, showWarnings = FALSE)
  for (prefix in c("original", "supplement")) {
    directory <- if (prefix == "original") original_dir else supplement_dir
    if (!dir.exists(directory)) next
    files <- list.files(directory,pattern="\\.csv$",full.names=TRUE)
    for (f in files) file.copy(f,file.path(report_dir,paste0(prefix,"_",basename(f))),overwrite=TRUE)
  }
  old_path <- file.path(original_dir,"rejection.csv")
  new_path <- file.path(supplement_dir,"rejection.csv")
  comparisons <- list()
  if (file.exists(old_path) && file.exists(new_path) && file.info(new_path)$size>10) {
    old <- read.csv(old_path,stringsAsFactors=FALSE)
    fresh <- read.csv(new_path,stringsAsFactors=FALSE)
    old <- old[old$part==1L,,drop=FALSE]
    fresh <- fresh[fresh$correction=="none" | (fresh$correction=="estimated" & fresh$alignment=="base"),,drop=FALSE]
    for (i in seq_len(nrow(fresh))) {
      z <- fresh[i,]
      method <- if (z$method=="energy") "QBP_median_energy" else "QBP_median_max"
      correction <- if (z$correction=="none") "uncorrected" else "corrected"
      bw <- if (z$correction=="none") 1 else z$bw_factor
      hit <- which(old$model==z$model & old$n==z$n & old$phi==z$phi &
        old$method==method & old$correction==correction &
        old$bw_factor==bw & old$block_factor==z$block_factor)
      if (length(hit)!=1L) next
      a <- old[hit,]
      comparisons[[length(comparisons)+1L]] <- data.frame(model=z$model,n=z$n,phi=z$phi,
        method=method,correction=correction,bw_factor=bw,block_factor=z$block_factor,
        original_R=a$R_completed,supplement_R=z$R_completed,
        original_rejection=a$rejection_rate,supplement_rejection=z$rejection_rate,
        difference=z$rejection_rate-a$rejection_rate,
        independent_MCSE=sqrt(a$MCSE^2+z$MCSE^2))
    }
  }
  comparison <- qbd_bind(comparisons)
  write.csv(comparison,file.path(report_dir,"original_vs_supplement.csv"),row.names=FALSE,na="")
  lines <- c("Quantile bispectrum: retained experiments and additional calibration diagnostics",
    "original_*.csv: retained original experiments, with their original Monte Carlo sample sizes.",
    "supplement_*.csv: additional diagnostics, summarized separately.",
    "original_vs_supplement.csv: matching original and new baseline settings; the two runs use independent random streams.",
    "The paired_rejection_difference table compares methods within the supplement on the same replications.",
    "No bandwidth, block length or alignment is selected automatically from rejection rates.")
  writeLines(lines,file.path(report_dir,"README.txt"))
  cat("Combined report:",report_dir,"\n")
  invisible(report_dir)
}

qbd_run_original <- function(settings, root) {
  old_root <- file.path(root,"original")
  out <- qbd_path(settings$ORIGINAL_OUTPUT_DIR,root)
  path <- file.path(out,"manifest.rds")
  if (file.exists(path)) {
    meta <- readRDS(path); cfg <- meta$config
    if (!dir.exists(file.path(out,"checkpoints")))
      stop("The original directory contains summary results without checkpoints. Use it as ORIGINAL_RESULTS_DIR; choose a new ORIGINAL_OUTPUT_DIR for a rerun.")
  } else {
    env <- new.env(parent=.GlobalEnv); sys.source(file.path(old_root,"config.R"),env)
    cfg <- env$qbp_make_config(settings$RUN_MODE)

    cfg$CHUNK_SIZE <- 5L
  }
  cfg$N_CORES <- settings$N_CORES
  cfg$RUN_PARTS <- settings$ORIGINAL_PARTS
  cfg$OUTPUT_DIR <- out; cfg$RESUME <- settings$RESUME; cfg$MAKE_PLOTS <- settings$MAKE_PLOTS
  qbp_run(cfg,old_root)
  invisible(out)
}

qbd_driver <- function(root, task=c("all","report")) {
  task <- match.arg(task)
  settings <- new.env(parent=.GlobalEnv);sys.source(file.path(root,"config.R"),settings)
  for (f in c("original/fn.R","original/engine.R","R/paths.R","R/supplement_functions.R",
              "R/supplement_summary.R","R/supplement_engine.R")) sys.source(file.path(root,f),.GlobalEnv)
  original_dir <- qbd_path(settings$ORIGINAL_RESULTS_DIR,root)
  supplement_dir <- qbd_path(settings$DIAG_CONFIG$OUTPUT_DIR,root)
  if (task=="all") {
    if (isTRUE(settings$RUN_ORIGINAL)) original_dir <- qbd_run_original(settings,root) else
      cat("Retaining original results from:",original_dir,"\n")
    if (isTRUE(settings$RUN_SUPPLEMENT)) supplement_dir <- qbd_run(settings$DIAG_CONFIG,root)
  }
  qbd_make_report(original_dir,supplement_dir,qbd_path(settings$REPORT_DIR,root))
  invisible(list(original=original_dir,supplement=supplement_dir))
}
