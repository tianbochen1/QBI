qbp_bind_rows <- function(xs) {
  xs <- Filter(function(x) !is.null(x) && nrow(x) > 0L, xs)
  if (!length(xs)) return(data.frame())
  out <- do.call(rbind, xs); rownames(out) <- NULL
  out
}

qbp_tag <- function(df, record) {
  if (is.null(df) || !nrow(df)) return(NULL)
  keys <- c("case_id", "part", "model", "n", "theta", "phi", "epsilon", "null_design")
  for (key in keys) df[[key]] <- record$case[[key]]
  if (!"margin" %in% names(df)) df$margin <- record$case$margin
  df$margin[df$margin == "original"] <- record$case$margin
  df$replication <- record$replication
  df
}

qbp_group_summary <- function(df, keys, FUN) {
  if (!nrow(df)) return(data.frame())
  key_values <- lapply(df[keys], function(x) ifelse(is.na(x), "<NA>", as.character(x)))
  groups <- split(seq_len(nrow(df)), do.call(paste, c(key_values, sep = "|")))
  out <- lapply(groups, function(i) cbind(df[i[1L], keys, drop = FALSE], FUN(df[i, , drop = FALSE])))
  qbp_bind_rows(out)
}

qbp_mc_interval <- function(count, total) {
  z <- qnorm(.975); p <- count / total
  center <- (p + z^2 / (2 * total)) / (1 + z^2 / total)
  half <- z * sqrt(p * (1 - p) / total + z^2 / (4 * total^2)) / (1 + z^2 / total)
  c(lower = max(0, center - half), upper = min(1, center + half))
}

qbp_collect <- function(directory) {
  files <- list.files(file.path(directory, "checkpoints"), pattern = "\\.rds$",
                      full.names = TRUE, recursive = TRUE)
  meta <- readRDS(file.path(directory, "manifest.rds"))
  tests <- covariance <- estimation <- invariance <- errors <- runtime <- numerical_ties <- list()
  seen <- new.env(parent = emptyenv()); counter <- 0L
  for (path in files) {
    chunk <- readRDS(path)
    if (!identical(chunk$fingerprint, meta$fingerprint)) stop("Mismatched checkpoint: ", path)
    for (r in chunk$results) {
      key <- paste(r$case$case_id, r$replication, sep = ":")
      if (exists(key, seen, inherits = FALSE)) stop("Duplicate replication: ", key)
      seen[[key]] <- TRUE; counter <- counter + 1L
      runtime[[counter]] <- qbp_tag(data.frame(elapsed_seconds = r$elapsed_seconds,
                                              status = r$status), r)
      numerical_ties[[counter]] <- qbp_tag(r$numerical_ties, r)
      if (r$status != "ok") {
        errors[[counter]] <- qbp_tag(data.frame(error = r$error, stringsAsFactors = FALSE), r)
      } else {
        tests[[counter]] <- qbp_tag(r$tests, r)
        covariance[[counter]] <- qbp_tag(r$covariance, r)
        estimation[[counter]] <- qbp_tag(r$estimation, r)
        invariance[[counter]] <- qbp_tag(r$invariance, r)
      }
    }
  }
  list(tests = qbp_bind_rows(tests), covariance = qbp_bind_rows(covariance),
       estimation = qbp_bind_rows(estimation), invariance = qbp_bind_rows(invariance),
       errors = qbp_bind_rows(errors), runtime = qbp_bind_rows(runtime),
       numerical_ties = qbp_bind_rows(numerical_ties), manifest = meta)
}

qbp_summarize <- function(directory) {
  results <- qbp_collect(directory)
  alpha <- results$manifest$config$ALPHA
  common <- c("case_id", "part", "model", "n", "theta", "phi", "epsilon", "margin", "null_design")
  tests <- results$tests
  if (nrow(tests)) tests$rejected <- tests$p_value <= alpha
  results$tests <- tests
  rejection <- qbp_group_summary(tests,
    c(common, "method", "calibration", "B", "correction", "bw_factor", "block_factor"), function(z) {
      R <- nrow(z); count <- sum(z$rejected); p <- count / R
      ci <- qbp_mc_interval(count, R)
      data.frame(R_completed = R, rejection_rate = p, MCSE = sqrt(p * (1 - p) / R),
                 MC_lower = ci[1L], MC_upper = ci[2L], mean_p_value = mean(z$p_value))
    })
  covariance <- qbp_group_summary(results$covariance,
    c(common, "h", "k", "correction", "bw_factor", "block_factor"), function(z) {
      R <- nrow(z); empirical <- if (R > 1L) var(z$estimate) else NA_real_
      estimated <- mean(z$estimated_variance); coverage <- mean(z$covered)
      data.frame(R_completed = R, mean_estimate = mean(z$estimate), empirical_variance = empirical,
                 mean_estimated_variance = estimated,
                 variance_ratio = if (is.finite(empirical) && empirical > 0) estimated / empirical else NA_real_,
                 coverage = coverage, coverage_MCSE = sqrt(coverage * (1 - coverage) / R),
                 bandwidth = z$bandwidth[1L], block_length = z$block_length[1L])
    })
  estimation <- qbp_group_summary(results$estimation,
    c(common, "scale", "estimator", "H", "M", "tau1", "tau2", "tau3"), function(z) {
      R <- nrow(z)
      data.frame(R_completed = R, mean_ISE = mean(z$ise), median_ISE = median(z$ise),
                 ISE_MCSE = if (R > 1L) sd(z$ise) / sqrt(R) else NA_real_,
                 mean_ISE_real = mean(z$ise_real), mean_ISE_imag = mean(z$ise_imag),
                 mean_stochastic_ISE = mean(z$stochastic_ise), window_bias_ISE = mean(z$window_bias_ise),
                 mean_cross_term = mean(z$cross_term))
    })
  invariance <- qbp_group_summary(results$invariance, common, function(z) {
    vars <- c("rank_difference", "moment_difference", "adjustment_difference",
              "covariance_difference", "multiplier_difference", "rank_p_difference")
    mx <- vapply(z[vars], max, numeric(1))
    cbind(data.frame(R_completed = nrow(z), passed = all(mx <= 1e-12)), as.data.frame(as.list(mx)))
  })
  runtime <- qbp_group_summary(results$runtime, common, function(z)
    data.frame(R_completed = sum(z$status == "ok"), R_failed = sum(z$status != "ok"),
               mean_seconds = mean(z$elapsed_seconds), total_worker_seconds = sum(z$elapsed_seconds)))
  completion <- results$manifest$design
  counts <- if (nrow(results$runtime)) table(results$runtime$case_id[results$runtime$status == "ok"]) else integer()
  completion$R_completed <- as.integer(counts[match(completion$case_id, names(counts))])
  completion$R_completed[is.na(completion$R_completed)] <- 0L
  completion$complete <- completion$R_completed == completion$replications
  summaries <- list(rejection = rejection, covariance = covariance, estimation = estimation,
                    invariance = invariance, runtime = runtime, completion = completion,
                    errors = results$errors, numerical_ties = results$numerical_ties)
  for (name in names(summaries))
    write.csv(summaries[[name]], file.path(directory, paste0(name, ".csv")), row.names = FALSE, na = "")
  save(results, summaries, file = file.path(directory, "simulation_results.RData"), compress = TRUE)
  cat(sprintf("Summaries saved: %d successful replications; %d failures.\n",
              sum(completion$R_completed), nrow(results$errors)))
  invisible(summaries)
}
