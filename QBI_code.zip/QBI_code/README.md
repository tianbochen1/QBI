# Quantile Bispectral Inference

Code for the simulation studies and the CWRU and SandyDuck applications in *Quantile Bispectral Inference for Third-Order Serial Dependence*.

Repository: https://github.com/tianbochen1/QBI

## Requirements

R 4.1 or later. Simulations and SandyDuck analyses use packages distributed with R. The CWRU analysis also requires `R.matlab`:

```r
install.packages("R.matlab")
```

The scripts use PSOCK workers on Windows, macOS and Linux. The default is eight workers. Set `N_CORES` in `simulation/config.R` and `WORKERS` in each application script to suit the available memory and processors. Random streams are assigned to tasks, independently of worker scheduling.

## Simulations

From the extracted `QBI_code` directory, run:

```sh
Rscript simulation/run_all.R
```

`simulation/config.R` defaults to `RUN_MODE = "paper"`, `RUN_ORIGINAL = TRUE` and `RUN_SUPPLEMENT = TRUE`. This runs all original Parts 0–6 and the Base/Lagged calibration study. The paper settings are computationally intensive. Set `RUN_MODE` to `"smoke"` for an execution check or `"pilot"` for a smaller experiment.

| Part | Experiment |
|---|---|
| 0 | Independent-null calibration under four margins |
| 1 | Gaussian and Student AR(1) nulls |
| 2 | Linear and even-loading block alternatives |
| 3 | Mixed-quantile alternatives |
| 4 | Estimation error against known bispectra |
| 5 | Invariance under increasing marginal transformations |
| 6 | Replacement contamination |
| Supplement | Base and Lagged corrections, bandwidths, block lengths and Gaussian oracle corrections |

`simulation/original/` contains the seven original experiments, estimation routines, summaries, plots and tests. `simulation/R/` contains the additional calibration routines and the combined report. Their Monte Carlo samples are separate. Original experiments use seed 20260923; the additional calibration uses seed 20260924.

Outputs are written under `simulation/results/`. For paper mode, `original_paper/` and `supplement_paper/` contain experiment results, and `report_paper/` contains combined CSV summaries. To rebuild a report from these outputs:

```sh
Rscript simulation/make_report.R
```

The small CSV files under `simulation/retained_results/` contain reference summaries from the original Monte Carlo run. They are not replication checkpoints. To reuse them, set `RUN_ORIGINAL = FALSE` and `ORIGINAL_RESULTS_DIR = "retained_results"` in `simulation/config.R`.

Successful checkpoints are reused when rerunning the same configuration with `RESUME = TRUE`. Failed replications are retried with their original random streams. Checkpoints are specific to the code and R version. Start with a new output directory when using this distribution; checkpoints produced by an earlier commented version may fail the source-file fingerprint check. Existing CSV summaries remain readable.

Run the numerical and execution checks with:

```sh
Rscript simulation/original/test_simulation.R
Rscript simulation/test_code.R
```

These checks cover moment calculations, spectral identities, marginal corrections, numerical ties, random streams, serial/parallel agreement and checkpoint recovery. They do not repeat the full paper experiment.

## Applications

The two scripts are self-contained:

```sh
Rscript applications/QBI_CWRU.R
Rscript applications/QBI_SandyDuck.R
```

Edit `INPUT_DIR` in the corresponding script to point to the existing data. The default directories are `applications/CWRU_data/` and `applications/SandyDuck_data/`. Results are written to the `OUTPUT_DIR` specified in each script.

Both scripts use seed 20260925 and 49,999 multiplier draws for the primary and sensitivity analyses. They retain Base/Lagged comparisons, block-length checks, tied-observation handling, planned-family Holm adjustment, short-window analyses and spectral summaries. The CWRU script includes the 900 Hz and 1350 Hz filter checks. SandyDuck includes linear-detrending sensitivity. Extended-lag and matched null-calibration calculations are controlled by `RUN_EXTENDED_LAGS` and `RUN_CALIBRATION`; the latter defaults to 500 replications with 999 multiplier draws.

The main outputs are `run_index.csv`, `all_stages_tests.csv`, `matched_sensitivity.csv`, `matched_spectral_sensitivity.csv` and the per-stage summaries and figures. Per-stage `errors.csv`, `warnings.csv` and input inventories record execution and data-quality issues. Tied windows are retained for descriptive summaries; unsupported rank-inference p-values are recorded as missing.

To load functions and change settings without starting an analysis immediately:

```r
options(qbp.skip.autorun = TRUE)
source("applications/QBI_CWRU.R")
CONFIG$INPUT_DIR <- "/path/to/CWRU_data"
CONFIG$WORKERS <- 4L
qs_main(CONFIG)
```

Use a separate R session for each application because the self-contained files define functions with the same names.

The following check uses synthetic series to verify the application routines, including two-worker agreement and checkpoint reuse:

```sh
Rscript applications/test_applications.R
```

### CWRU data

Source: https://engineering.case.edu/bearingdatacenter

The analysis uses the drive-end channel in the 12 files `97.mat`–`100.mat`, `109.mat`–`112.mat` and `135.mat`–`138.mat`, covering normal, inner-race and outer-race conditions at four loads. The sampling rate is 48 kHz. The script applies the specified FIR filter and decimation factor of 16 before windowing.

### SandyDuck data

Steve Elgar and Britt Raubenheimer (2023), *SandyDuck 1997 Timeseries*, version 1. DOI: https://doi.org/10.5281/zenodo.8286465

The analysis uses runs `10011000`, `10021000` and `10031000`, with velocity sensors `u12`, `u13` and `u15`. Place the extracted records or the October archive below `INPUT_DIR`. The loader searches subdirectories and can extract selected records from a local archive.

### Optional downloads

Existing data can be used directly. For a new installation, the following functions retrieve the selected public inputs:

```r
source("applications/download_data.R")
qbi_download_cwru("applications/CWRU_data")
qbi_download_sandyduck("applications/SandyDuck_data")
```

The SandyDuck function downloads the approximately 1.9 GB October archive if the selected records are absent, verifies the published MD5 checksum and extracts the selected records. Raw third-party data are not redistributed in this package.

## Manuscript figures

The R scripts generate diagnostic plots. The three simulation figures used in the manuscript can also be rebuilt from the combined CSV summaries with the supplied Python plotting script:

```sh
python -m pip install -r figures/requirements.txt
python figures/make_simulation_figures.py --data simulation/results/report_paper
```

The output directory is `figures/output/frames/`. This step requires NumPy, pandas and Matplotlib; it does not rerun simulations.
