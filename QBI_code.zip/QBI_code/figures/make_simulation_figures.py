from pathlib import Path
import argparse
import io
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument('--data', type=Path, default=Path(__file__).resolve().parents[1] / 'simulation/results/report_paper')
parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parent / 'output')
args = parser.parse_args()
DATA = args.data
OUT = args.output
(OUT / 'frames').mkdir(parents=True, exist_ok=True)
r = pd.read_csv(DATA / 'original_rejection.csv')
d = pd.read_csv(DATA / 'supplement_rejection.csv')

def pick(df,**kw):
    a=df
    for k,v in kw.items(): a=a[a[k].isin(v)] if isinstance(v,(list,tuple)) else a[a[k]==v]
    return a

def one(df,**kw):
    a=pick(df,**kw)
    assert len(a)==1,(kw,len(a))
    return a.iloc[0]

METHODS=['Ordinary_bispectrum','Pairwise_rank','QBP_median','QBP_diagonal','QBP_mixed','QBP_mixed_max']
LABELS={'Ordinary_bispectrum':'Ordinary','Pairwise_rank':'Pairwise','QBP_median':'Median','QBP_diagonal':'Diagonal','QBP_mixed':'Mixed','QBP_mixed_max':'Maximum','QBP_ordered6':'Six-tuple'}
COLORS=['#333333','#009E73','#999999','#0072B2','#D55E00','#CC79A7','#C49A00']
MARKERS=['o','s','v','^','D','P','X']
plt.rcParams.update({'font.family':'serif','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})

def save(fig,name):
    buffer=io.BytesIO()
    fig.savefig(buffer,format='pdf',bbox_inches='tight')
    content=buffer.getvalue()
    assert content.rstrip().endswith(b'%%EOF'),name
    (OUT/'frames'/(name+'.pdf')).write_bytes(content)
    fig.savefig(OUT/'frames'/(name+'.png'),dpi=160,bbox_inches='tight')
    plt.close(fig)

fig,axs=plt.subplots(2,3,figsize=(10.7,6.8),sharex=True,sharey=True)
for i,model in enumerate(['linear','even']):
    for j,n in enumerate([512,2048,8192]):
        ax=axs[i,j]
        for k,method in enumerate(METHODS):
            a=pick(r,part=2,model=model,n=n,method=method).sort_values('theta')
            ax.plot(a.theta,a.rejection_rate,color=COLORS[k],marker=MARKERS[k],ms=4,lw=1.4,label=LABELS[method])
            ax.vlines(a.theta,a.MC_lower,a.MC_upper,color=COLORS[k],alpha=.45,lw=.6)
        ax.axhline(.05,color='#777777',ls=':',lw=.8)
        ax.set_title(f'{model.capitalize()}, n = {n:,}')
        ax.set_xticks([0,.3,.6,.9])
        ax.set_ylim(-.02,1.04)
        ax.grid(axis='y',alpha=.13)
        if i==1:ax.set_xlabel(r'$\theta$')
        if j==0:ax.set_ylabel('Rejection proportion')
fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=6,frameon=False,bbox_to_anchor=(.5,-.005),columnspacing=1.2,handlelength=1.7)
fig.tight_layout(rect=(0,.065,1,1))
save(fig,'simulation_identification')

fig,axs=plt.subplots(1,3,figsize=(10.7,3.75),sharey=True)
for j,n in enumerate([4096,16384,65536]):
    ax=axs[j]
    for k,method in enumerate(METHODS+['QBP_ordered6']):
        a=pick(r,part=3,n=n,method=method).sort_values('theta')
        ax.plot(a.theta,a.rejection_rate,color=COLORS[k],marker=MARKERS[k],ms=4,lw=1.4,label=LABELS[method])
        ax.vlines(a.theta,a.MC_lower,a.MC_upper,color=COLORS[k],alpha=.45,lw=.6)
    ax.axhline(.05,color='#777777',ls=':',lw=.8)
    ax.set_title(f'n = {n:,}')
    ax.set_xticks([0,.3,.6,.9]);ax.set_xlabel(r'$\theta$')
    ax.set_ylim(-.015,.72);ax.grid(axis='y',alpha=.13)
    if j==0:ax.set_ylabel('Rejection proportion')
fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=4,frameon=False,bbox_to_anchor=(.5,-.015),columnspacing=1.5,handlelength=1.8)
fig.tight_layout(rect=(0,.15,1,1))
save(fig,'simulation_mixed')

fig,axs=plt.subplots(2,2,figsize=(9.6,6.6),sharex=True,sharey=True)
for i,method in enumerate(['energy','maximum']):
    for j,model in enumerate(['normal','t5']):
        ax=axs[i,j]
        specs=[('estimated','base','#D55E00','o','-','Estimated m, base'),('estimated','lagged','#0072B2','s','-','Estimated m, lagged'),('oracle_m','base','#D55E00','o','--','Oracle m, base'),('oracle_m','lagged','#0072B2','s','--','Oracle m, lagged')]
        for source,alignment,color,marker,ls,label in specs:
            a=pick(d,model=model,phi=.7,method=method,correction=source,alignment=alignment,block_factor=1)
            if source=='estimated':a=pick(a,bw_factor=1)
            a=a.sort_values('n')
            if a.empty:continue
            ax.plot(a.n,a.rejection_rate,color=color,marker=marker,ls=ls,lw=1.5,ms=4,label=label,markerfacecolor=color if source=='estimated' else 'white')
        ax.axhspan(.0405,.06,color='#eeeeee')
        ax.axhline(.05,color='#777777',lw=.8)
        ax.set_title(('Gaussian' if model=='normal' else r'$t_5$')+', '+method.capitalize())
        ax.set_xscale('log',base=2);ax.set_xticks([512,1024,2048,4096,8192],['512','1024','2048','4096','8192'])
        ax.set_ylim(0,.085);ax.grid(axis='y',alpha=.13)
        if i==1:ax.set_xlabel('n')
        if j==0:ax.set_ylabel('Rejection proportion')
fig.legend(*axs[0,0].get_legend_handles_labels(),loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.5,-.01))
fig.tight_layout(rect=(0,.10,1,1))
save(fig,'simulation_calibration')
