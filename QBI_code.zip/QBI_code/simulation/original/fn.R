QBP_CODE_VERSION <- "1.0.1"
.qbp_cache <- new.env(parent = emptyenv())

qbp_resolve_simulation_ties <- function(x, bounds = c(-Inf, Inf)) {
  empty <- list(values = x, groups = 0L, observations = 0L, max_change = 0)
  if (!anyDuplicated(x)) return(empty)
  if (any(!is.finite(x)) || length(bounds) != 2L ||
      any(x <= bounds[1L] | x >= bounds[2L]))
    stop("Cannot resolve numerical ties outside the simulation support.")
  ord <- order(x); sx <- x[ord]
  runs <- rle(sx); ends <- cumsum(runs$lengths)
  starts <- ends - runs$lengths + 1L
  groups <- which(runs$lengths > 1L)
  ans <- x
  for (g in groups) {
    value <- runs$values[g]; m <- runs$lengths[g]
    lo <- if (g == 1L) bounds[1L] else runs$values[g - 1L]
    hi <- if (g == length(runs$values)) bounds[2L] else runs$values[g + 1L]

    radius <- min(64 * .Machine$double.eps * max(1, abs(value)) * m,
                  (value - lo) / 4, (hi - value) / 4)
    values <- value + seq(-radius, radius, length.out = m)
    if (anyDuplicated(values) || any(values <= lo | values >= hi))
      stop("Insufficient floating-point spacing to resolve simulation ties.")
    positions <- ord[seq.int(starts[g], ends[g])]
    ans[positions] <- values[sample.int(m)]
  }
  if (anyDuplicated(ans)) stop("Numerical tie resolution failed.")
  list(values = ans, groups = length(groups),
       observations = sum(runs$lengths[groups]), max_change = max(abs(ans - x)))
}

qbp_check_series <- function(y) {
  if (!is.numeric(y) || length(y) < 10L || any(!is.finite(y)))
    stop("The series must contain at least 10 finite numeric observations.")
  if (anyDuplicated(y)) stop("Ties detected. The manuscript assumes continuous margins without ties.")
  invisible(TRUE)
}

qbp_g <- function(u, model = c("linear", "even", "mixed"), j = 1L) {
  model <- match.arg(model)
  if (model == "linear") return(1 - 2 * u)
  if (model == "even") return(tanh(8 * cos(2 * pi * u)) / tanh(8))
  x <- 3 * u - j + 1
  out <- numeric(length(u)); keep <- x > 0 & x < 1
  out[keep] <- tanh(8 * sin(2 * pi * x[keep])) / tanh(8)
  out
}

qbp_G <- function(tau, model, j = 1L) {
  vapply(tau, function(t) {
    if (model == "linear") return(t * (1 - t))
    key <- paste("G", model, j, sprintf("%.17g", t), sep = "_")
    if (exists(key, .qbp_cache, inherits = FALSE)) return(.qbp_cache[[key]])
    if (model == "mixed" && (t <= (j - 1) / 3 || t >= j / 3)) ans <- 0 else {
      lower <- if (model == "mixed") (j - 1) / 3 else 0
      ans <- integrate(function(u) qbp_g(u, model, j), lower, t,
                       rel.tol = 1e-10, abs.tol = 1e-12)$value
      if (abs(ans) < 1e-13) ans <- 0
    }
    .qbp_cache[[key]] <- ans
    ans
  }, numeric(1))
}

qbp_block_uniform <- function(n, theta, model = c("linear", "even", "mixed")) {
  model <- match.arg(model)
  stopifnot(n >= 2L, length(theta) == 1L, abs(theta) < 1)
  first_length <- sample(c(3L, 4L), 1L, prob = c(3, 4))
  first_position <- sample.int(first_length, 1L)
  lengths <- c(first_length, sample(c(3L, 4L), ceiling(n / 3) + 1L, replace = TRUE))
  cumulative <- cumsum(lengths)
  nb <- which(cumulative >= n + first_position - 1L)[1L]
  lengths <- lengths[seq_len(nb)]
  triples <- matrix(NA_real_, nb, 3L)
  pending <- seq_len(nb)
  while (length(pending)) {
    m <- length(pending)
    proposed <- matrix(runif(3L * m), m, 3L)
    prod_g <- qbp_g(proposed[, 1L], model, 1L) *
      qbp_g(proposed[, 2L], model, 2L) * qbp_g(proposed[, 3L], model, 3L)
    accept <- runif(m) <= (1 + theta * prod_g) / (1 + abs(theta))
    if (any(accept)) triples[pending[accept], ] <- proposed[accept, , drop = FALSE]
    pending <- pending[!accept]
  }
  starts <- c(1L, head(cumsum(lengths), -1L) + 1L)
  out <- numeric(sum(lengths))
  for (j in 1:3) out[starts + j - 1L] <- triples[, j]
  fourth <- starts[lengths == 4L] + 3L
  out[fourth] <- runif(length(fourth))
  out[seq.int(first_position, length.out = n)]
}

qbp_transform <- function(v, margin) {
  switch(margin, uniform = sqrt(12) * (v - 0.5), normal = qnorm(v),
         t5 = qt(v, df = 5) / sqrt(5 / 3), cauchy = qcauchy(v),
         lognormal = exp(qnorm(v)), stop("Unknown marginal distribution: ", margin))
}

qbp_ar1 <- function(n, phi, innovation = c("normal", "t5"), burn = 2000L) {
  innovation <- match.arg(innovation)
  stopifnot(abs(phi) < 1)
  if (innovation == "normal") {
    first <- rnorm(1L)
    if (phi == 0) return(c(first, rnorm(n - 1L)))
    rest <- as.numeric(stats::filter(rnorm(n - 1L, sd = sqrt(1 - phi^2)),
                                    phi, method = "recursive", init = first))
    return(c(first, rest))
  }
  eps <- rt(n + burn, df = 5) / sqrt(5 / 3)
  if (phi == 0) return(tail(eps, n))
  tail(as.numeric(stats::filter(eps, phi, method = "recursive", init = 0)), n)
}

qbp_contaminate <- function(y, epsilon, magnitude = 20, jitter_sd = 0.05) {
  stopifnot(epsilon >= 0, epsilon <= 1, jitter_sd > 0)
  take <- which(runif(length(y)) < epsilon)
  if (length(take)) y[take] <- sample(c(-1, 1), length(take), replace = TRUE) *
    magnitude + rnorm(length(take), sd = jitter_sd)
  y
}

qbp_context <- function(n, H = 3L, levels = c(0.25, 0.5, 0.75)) {
  levels <- sort(unique(as.numeric(levels)))
  stopifnot(H >= 2, H < n - 2L, all(levels > 0 & levels < 1))
  key <- paste("ctx", n, H, paste(sprintf("%.17g", levels), collapse = ":"), sep = "_")
  if (exists(key, .qbp_cache, inherits = FALSE)) return(.qbp_cache[[key]])
  q <- length(levels); K <- q + 1L
  tuples <- as.matrix(expand.grid(a = seq_len(q), b = seq_len(q), c = seq_len(q)))
  categories <- as.matrix(expand.grid(a = 0:q, b = 0:q, c = 0:q))
  uc <- sweep(outer(0:q, seq_len(q) - 1L, "<="), 2L, levels, "-")
  weights3 <- uc[categories[, 1L] + 1L, tuples[, 1L], drop = FALSE] *
    uc[categories[, 2L] + 1L, tuples[, 2L], drop = FALSE] *
    uc[categories[, 3L] + 1L, tuples[, 3L], drop = FALSE]
  pairs <- as.matrix(expand.grid(a = seq_len(q), b = seq_len(q)))
  cp <- as.matrix(expand.grid(a = 0:q, b = 0:q))
  weights2 <- uc[cp[, 1L] + 1L, pairs[, 1L], drop = FALSE] *
    uc[cp[, 2L] + 1L, pairs[, 2L], drop = FALSE]
  lags <- t(combn(seq_len(H), 2L)); colnames(lags) <- c("h", "k")
  tau <- matrix(levels[tuples], nrow(tuples), 3L)
  tau_pair <- matrix(levels[pairs], nrow(pairs), 2L)
  v3 <- apply(tau * (1 - tau), 1L, prod)
  v2 <- apply(tau_pair * (1 - tau_pair), 1L, prod)
  diagonal <- which(tuples[, 1L] == tuples[, 2L] & tuples[, 2L] == tuples[, 3L])
  median <- which(rowSums(abs(tau - 0.5)) < 1e-14)
  distinct <- which(tuples[, 1L] != tuples[, 2L] & tuples[, 1L] != tuples[, 3L] &
                      tuples[, 2L] != tuples[, 3L])
  idx <- do.call(rbind, lapply(seq_len(nrow(lags)), function(i)
    data.frame(h = unname(lags[i, 1L]), k = unname(lags[i, 2L]), tuples,
               tau1 = tau[, 1L], tau2 = tau[, 2L], tau3 = tau[, 3L])))
  names(idx)[3:5] <- c("a", "b", "c")
  ans <- list(n = as.integer(n), H = as.integer(H), N = as.integer(n - H), q = q,
              K = K, levels = levels, tuples = tuples, tau = tau, lags = lags,
              weights3 = weights3, weights2 = weights2, v3 = v3, v2 = v2,
              diagonal = diagonal, median = median, distinct = distinct,
              index = idx, tuple_keys = apply(tuples, 1L, paste, collapse = ":"))
  .qbp_cache[[key]] <- ans
  ans
}

qbp_rank_data <- function(y, ctx) {
  qbp_check_series(y)
  if (length(y) != ctx$n) stop("Series length and context disagree.")
  r <- rank(y, ties.method = "first")
  list(v = r / ctx$n,
       category = findInterval(r, floor(ctx$n * ctx$levels), left.open = TRUE))
}

qbp_moments <- function(category, ctx, edge = c("common", "span")) {
  edge <- match.arg(edge)
  out <- matrix(0, nrow(ctx$lags), nrow(ctx$tuples))
  for (i in seq_len(nrow(ctx$lags))) {
    h <- ctx$lags[i, 1L]; k <- ctx$lags[i, 2L]
    N <- if (edge == "common") ctx$N else ctx$n - k
    t <- seq_len(N)
    code <- category[t] + ctx$K * category[t + h] + ctx$K^2 * category[t + k] + 1L
    out[i, ] <- as.numeric(crossprod(tabulate(code, nbins = ctx$K^3), ctx$weights3)) / N
  }
  out
}

qbp_pair_stat <- function(category, ctx) {
  t <- seq_len(ctx$N); value <- 0
  for (h in seq_len(ctx$H)) {
    code <- category[t] + ctx$K * category[t + h] + 1L
    g <- as.numeric(crossprod(tabulate(code, nbins = ctx$K^2), ctx$weights2)) / ctx$N
    value <- value + sum(g^2 / ctx$v2)
  }
  ctx$n * value
}

qbp_standardize <- function(y) {

  z <- y / max(abs(y))
  s <- sd(z)
  if (!is.finite(s) || s <= 0) stop("Degenerate ordinary-statistic scale.")
  (z - mean(z)) / s
}

qbp_ordinary_stat <- function(z, ctx) {
  t <- seq_len(ctx$N)
  m <- vapply(seq_len(nrow(ctx$lags)), function(i)
    mean(z[t] * z[t + ctx$lags[i, 1L]] * z[t + ctx$lags[i, 2L]]), numeric(1))
  ctx$n * 6 / (2 * pi)^2 * sum(m^2)
}

qbp_rank_statistics <- function(category, ctx, ordered6 = FALSE) {
  km <- qbp_moments(category, ctx)
  s <- sweep(km^2, 2L, ctx$v3, "/")
  factor <- ctx$n * 6 / (2 * pi)^2
  ans <- c(QBP_median = factor * sum(s[, ctx$median, drop = FALSE]),
           QBP_diagonal = factor * sum(s[, ctx$diagonal, drop = FALSE]),
           QBP_mixed = factor * sum(s),
           QBP_mixed_max = sqrt(ctx$n * max(s)),
           Pairwise_rank = qbp_pair_stat(category, ctx))
  if (!length(ctx$median)) ans <- ans[names(ans) != "QBP_median"]
  if (ordered6) {
    if (ctx$q != 3L) stop("The six-tuple test requires exactly three quantile levels.")
    ans <- c(ans, QBP_ordered6 = factor * sum(s[, ctx$distinct, drop = FALSE]))
  }
  ans
}

qbp_ge <- function(a, b) a >= b - 64 * .Machine$double.eps * pmax(1, abs(b))

qbp_permutation_tests <- function(y, ctx, B = 999L, ordered6 = FALSE) {
  if (is.null(dim(y))) y <- matrix(y, ncol = 1L, dimnames = list(NULL, "original"))
  if (is.null(colnames(y))) colnames(y) <- paste0("margin", seq_len(ncol(y)))
  ranks <- lapply(seq_len(ncol(y)), function(j) qbp_rank_data(y[, j], ctx))
  for (j in seq_along(ranks))
    if (!identical(ranks[[1L]]$v, ranks[[j]]$v))
      stop("The multiple-margin interface requires identical ranks in all columns.")
  cat <- ranks[[1L]]$category
  z <- vapply(seq_len(ncol(y)), function(j) qbp_standardize(y[, j]), numeric(ctx$n))
  observed_rank <- qbp_rank_statistics(cat, ctx, ordered6)
  observed_raw <- vapply(seq_len(ncol(z)), function(j) qbp_ordinary_stat(z[, j], ctx), numeric(1))
  count_rank <- numeric(length(observed_rank)); count_raw <- numeric(length(observed_raw))
  for (b in seq_len(B)) {
    p <- sample.int(ctx$n)
    s <- qbp_rank_statistics(cat[p], ctx, ordered6)
    count_rank <- count_rank + qbp_ge(s, observed_rank)
    sr <- vapply(seq_len(ncol(z)), function(j) qbp_ordinary_stat(z[p, j], ctx), numeric(1))
    count_raw <- count_raw + qbp_ge(sr, observed_raw)
  }
  do.call(rbind, lapply(seq_len(ncol(y)), function(j)
    data.frame(margin = colnames(y)[j], method = c(names(observed_rank), "Ordinary_bispectrum"),
               statistic = c(observed_rank, observed_raw[j]),
               p_value = c((count_rank + 1) / (B + 1), (count_raw[j] + 1) / (B + 1)),
               calibration = "iid_permutation", B = B, correction = "none",
               bw_factor = NA_real_, block_factor = NA_real_, stringsAsFactors = FALSE)))
}

qbp_influence <- function(v, ctx, bw_factor = 1) {
  stopifnot(length(v) == ctx$n, all(v > 0 & v <= 1), bw_factor > 0)
  U <- sweep(outer(v, ctx$levels, "<="), 2L, ctx$levels, "-")
  bandwidth <- bw_factor * ctx$n^(-1 / 6)
  kw <- pmax(1 - abs(outer(v, ctx$levels, "-")) / bandwidth, 0)
  t <- seq_len(ctx$N); d <- nrow(ctx$index); nt <- nrow(ctx$tuples)
  raw <- corrected <- matrix(0, ctx$N, d)
  mhat <- matrix(0, d, 3L); kappa <- numeric(d)
  divide <- function(num, den) ifelse(den > 0, num / pmax(den, .Machine$double.xmin), 0)
  for (i in seq_len(nrow(ctx$lags))) {
    h <- ctx$lags[i, 1L]; k <- ctx$lags[i, 2L]
    ix <- (i - 1L) * nt + seq_len(nt)
    a <- ctx$tuples[, 1L]; b <- ctx$tuples[, 2L]; c <- ctx$tuples[, 3L]
    u1 <- U[t, a, drop = FALSE]; u2 <- U[t + h, b, drop = FALSE]
    u3 <- U[t + k, c, drop = FALSE]
    product <- u1 * u2 * u3
    kappa[ix] <- colMeans(product)
    raw[, ix] <- sweep(product, 2L, kappa[ix], "-")
    w <- kw[t, a, drop = FALSE]
    mhat[ix, 1L] <- divide(colSums(w * u2 * u3), colSums(w))
    w <- kw[t + h, b, drop = FALSE]
    mhat[ix, 2L] <- divide(colSums(w * u1 * u3), colSums(w))
    w <- kw[t + k, c, drop = FALSE]
    mhat[ix, 3L] <- divide(colSums(w * u1 * u2), colSums(w))
    corrected[, ix] <- raw[, ix] - sweep(U[t, a, drop = FALSE], 2L, mhat[ix, 1L], "*") -
      sweep(U[t, b, drop = FALSE], 2L, mhat[ix, 2L], "*") -
      sweep(U[t, c, drop = FALSE], 2L, mhat[ix, 3L], "*")
  }
  list(kappa = kappa, mhat = mhat, raw = raw, corrected = corrected, bandwidth = bandwidth)
}

qbp_block_covariance <- function(score, n, block_factor = 1) {
  N <- nrow(score)
  l <- max(1L, ceiling(block_factor * ceiling(log(n))))
  q <- N %/% l
  if (q < 2L) stop("Too few blocks for covariance estimation.")
  centered <- sweep(score, 2L, colMeans(score), "-")
  S <- rowsum(centered[seq_len(q * l), , drop = FALSE],
              rep(seq_len(q), each = l), reorder = FALSE)
  list(omega = crossprod(S) / N, S = S, length = l, N = N)
}

qbp_gaussian <- function(omega, B, z = NULL) {
  d <- nrow(omega)
  if (is.null(z)) z <- matrix(rnorm(B * d), B, d)
  stopifnot(nrow(z) == B, ncol(z) == d)
  e <- eigen((omega + t(omega)) / 2, symmetric = TRUE)
  if (min(e$values) < -1e-9 * max(1, max(abs(e$values))))
    stop("Covariance matrix is not positive semidefinite.")
  tcrossprod(sweep(z, 2L, sqrt(pmax(e$values, 0)), "*"), e$vectors)
}

qbp_dependent_tests <- function(y, cfg) {
  ctx <- qbp_context(length(y), cfg$H, 0.5)
  v <- qbp_rank_data(y, ctx)$v
  tuning <- cfg$TUNING
  fits <- lapply(unique(tuning$bw_factor), function(b) qbp_influence(v, ctx, b))
  names(fits) <- as.character(unique(tuning$bw_factor))
  B <- cfg$B_MULTIPLIER; d <- nrow(ctx$index)
  z <- matrix(rnorm(B * d), B, d)
  tests <- list(); covrows <- list(); k <- 0L
  variance0 <- prod(rep(0.5 * 0.5, 3L))
  for (i in seq_len(nrow(tuning))) {
    fit <- fits[[as.character(tuning$bw_factor[i])]]
    for (correction in c("corrected", "uncorrected")) {
      score <- if (correction == "corrected") fit$corrected else fit$raw
      covfit <- qbp_block_covariance(score, ctx$n, tuning$block_factor[i])
      omega <- covfit$omega
      sd0 <- sqrt(diag(omega))
      if (any(!is.finite(sd0) | sd0 <= 0)) stop("Zero estimated influence variance.")
      draws <- qbp_gaussian(omega, B, z)
      factor <- 6 / (2 * pi)^2 / variance0
      obs <- c(QBP_median_energy = ctx$n * factor * sum(fit$kappa^2),
               QBP_median_max = sqrt(ctx$n) * max(abs(fit$kappa) / sd0))
      boot <- cbind(factor * rowSums(draws^2),
                    apply(abs(sweep(draws, 2L, sd0, "/")), 1L, max))
      pv <- vapply(seq_along(obs), function(j)
        (1 + sum(qbp_ge(boot[, j], obs[j]))) / (B + 1), numeric(1))
      k <- k + 1L
      tests[[k]] <- data.frame(margin = "original", method = names(obs), statistic = unname(obs),
                              p_value = pv, calibration = "Gaussian_multiplier", B = B,
                              correction = correction, bw_factor = tuning$bw_factor[i],
                              block_factor = tuning$block_factor[i])
      se <- sd0 / sqrt(ctx$n)
      covrows[[k]] <- data.frame(h = ctx$index$h, k = ctx$index$k,
                                correction = correction, bw_factor = tuning$bw_factor[i],
                                block_factor = tuning$block_factor[i],
                                bandwidth = fit$bandwidth, block_length = covfit$length,
                                estimate = fit$kappa, estimated_variance = se^2,
                                covered = abs(fit$kappa) <= qnorm(0.975) * se)
    }
  }
  list(tests = do.call(rbind, tests), covariance = do.call(rbind, covrows))
}

qbp_truth <- function(ctx, theta, model) {
  g <- qbp_G(ctx$tau[, 1L], model, 1L) * qbp_G(ctx$tau[, 2L], model, 2L) *
    qbp_G(ctx$tau[, 3L], model, 3L) * 2 * theta / 7
  out <- matrix(0, nrow(ctx$lags), nrow(ctx$tuples))
  hit <- which(ctx$lags[, 1L] == 1L & ctx$lags[, 2L] == 2L)
  out[hit, ] <- rep(g, each = length(hit))
  out
}

qbp_coefficients <- function(kappa, ctx, tuple, weights = rep(1, nrow(ctx$lags))) {
  a <- match(tuple, ctx$levels)
  if (anyNA(a)) stop("Requested tuple is not on the quantile grid.")
  perm <- rbind(a[c(1, 2, 3)], a[c(1, 3, 2)], a[c(2, 1, 3)],
                a[c(3, 1, 2)], a[c(2, 3, 1)], a[c(3, 2, 1)])
  cols <- match(apply(perm, 1L, paste, collapse = ":"), ctx$tuple_keys)
  out <- lapply(seq_len(nrow(ctx$lags)), function(i) {
    h <- ctx$lags[i, 1L]; k <- ctx$lags[i, 2L]
    data.frame(h = c(h, k, -h, k - h, -k, h - k),
               k = c(k, h, k - h, -h, h - k, -k),
               coefficient = weights[i] * kappa[i, cols])
  })
  do.call(rbind, out)
}

qbp_ise <- function(error, h, k) {
  neg <- match(paste(-h, -k, sep = ":"), paste(h, k, sep = ":"))
  if (anyNA(neg)) stop("Lag set is not closed under negation.")
  re <- (error + error[neg]) / 2
  im <- (error - error[neg]) / 2
  c(ise = sum(error^2) / (2 * pi)^2,
    ise_real = sum(re^2) / (2 * pi)^2, ise_imag = sum(im^2) / (2 * pi)^2)
}

qbp_estimation <- function(v, theta, model, cfg) {
  n <- length(v); levels <- cfg$LEVELS
  cfix <- qbp_context(n, cfg$H, levels)
  cwin <- qbp_context(n, max(cfg$M_VALUES) - 1L, levels)
  vr <- rank(v) / n
  out <- list(); id <- 0L
  for (scale in c("rank", "oracle")) {
    vv <- if (scale == "rank") vr else v
    cat_fixed <- if (scale == "rank") qbp_rank_data(v, cfix)$category else
      findInterval(vv, levels, left.open = TRUE)
    km_fixed <- qbp_moments(cat_fixed, cfix, "common")
    km_window <- qbp_moments(cat_fixed, cwin, "span")
    for (resolution in c(NA_real_, cfg$M_VALUES)) {
      ctx <- if (is.na(resolution)) cfix else cwin
      km <- if (is.na(resolution)) km_fixed else km_window
      weights <- if (is.na(resolution)) rep(1, nrow(ctx$lags)) else {
        h <- ctx$lags[, 1L]; k <- ctx$lags[, 2L]; M <- resolution
        pmax(1 - h / M, 0) * pmax(1 - k / M, 0) * pmax(1 - (k - h) / M, 0)
      }
      truth <- qbp_truth(ctx, theta, model)
      for (j in seq_len(nrow(cfg$EST_TUPLES))) {
        tau <- cfg$EST_TUPLES[j, ]
        est <- qbp_coefficients(km, ctx, tau, weights)
        tr <- qbp_coefficients(truth, ctx, tau)
        wt <- qbp_coefficients(truth, ctx, tau, weights)
        err <- qbp_ise(est$coefficient - tr$coefficient, est$h, est$k)
        stochastic <- qbp_ise(est$coefficient - wt$coefficient, est$h, est$k)["ise"]
        bias <- qbp_ise(wt$coefficient - tr$coefficient, est$h, est$k)["ise"]
        id <- id + 1L
        out[[id]] <- data.frame(scale = scale, estimator = if (is.na(resolution)) "fixed_H" else "lag_window",
                                H = cfg$H, M = resolution, tau1 = tau[1L], tau2 = tau[2L], tau3 = tau[3L],
                                ise = unname(err["ise"]), ise_real = unname(err["ise_real"]),
                                ise_imag = unname(err["ise_imag"]),
                                stochastic_ise = unname(stochastic), window_bias_ise = unname(bias),
                                cross_term = unname(err["ise"] - stochastic - bias))
      }
    }
  }
  do.call(rbind, out)
}

qbp_invariance <- function(v, cfg) {
  margins <- c("normal", "t5", "cauchy")
  Y <- vapply(margins, function(m) qbp_transform(v, m), numeric(length(v)))
  colnames(Y) <- margins
  ctx <- qbp_context(length(v), cfg$H, cfg$LEVELS)
  fit <- lapply(seq_along(margins), function(j)
    qbp_influence(qbp_rank_data(Y[, j], ctx)$v, ctx))
  covs <- lapply(fit, function(x) qbp_block_covariance(x$corrected, ctx$n)$omega)
  z <- matrix(rnorm(10L * nrow(ctx$index)), 10L, nrow(ctx$index))
  draws <- lapply(covs, qbp_gaussian, B = 10L, z = z)
  checks <- do.call(rbind, lapply(seq_along(margins), function(j)
    data.frame(margin = margins[j], rank_difference = max(abs(rank(Y[, j]) - rank(Y[, 1L]))),
               moment_difference = max(abs(fit[[j]]$kappa - fit[[1L]]$kappa)),
               adjustment_difference = max(abs(fit[[j]]$mhat - fit[[1L]]$mhat)),
               covariance_difference = max(abs(covs[[j]] - covs[[1L]])),
               multiplier_difference = max(abs(draws[[j]] - draws[[1L]])))))
  tests <- qbp_permutation_tests(Y, ctx, cfg$B_PERMUTATION)
  ref <- tests[tests$margin == margins[1L] & tests$method != "Ordinary_bispectrum", ]
  checks$rank_p_difference <- vapply(margins, function(m) {
    got <- tests[tests$margin == m & tests$method != "Ordinary_bispectrum", ]
    max(abs(got$p_value - ref$p_value))
  }, numeric(1))
  list(tests = tests, invariance = checks)
}

qbp_one_replication <- function(case, cfg, seed, replication) {
  RNGkind("L'Ecuyer-CMRG", normal.kind = "Inversion", sample.kind = "Rejection")
  assign(".Random.seed", seed, envir = .GlobalEnv)
  start <- proc.time()[["elapsed"]]
  tie_records <- list()
  resolve <- function(x, stage, bounds = c(-Inf, Inf)) {
    ans <- qbp_resolve_simulation_ties(x, bounds)
    if (ans$groups > 0L)
      tie_records[[length(tie_records) + 1L]] <<-
        data.frame(stage = stage, groups = ans$groups,
                   observations = ans$observations, max_change = ans$max_change)
    ans$values
  }
  out <- tryCatch({
    part <- case$part; n <- case$n
    if (part == 0L) {
      y <- resolve(qbp_transform(runif(n), case$margin), "observed_iid")
      list(tests = qbp_permutation_tests(y, qbp_context(n, cfg$H, cfg$LEVELS), cfg$B_PERMUTATION))
    } else if (part == 1L) {
      y <- resolve(qbp_ar1(n, case$phi, case$model, cfg$AR_BURN), "observed_AR1")
      qbp_dependent_tests(y, cfg)
    } else {
      v <- resolve(qbp_block_uniform(n, case$theta, case$model), "latent_uniform", c(0, 1))
      if (part == 4L) list(estimation = qbp_estimation(v, case$theta, case$model, cfg)) else
        if (part == 5L) qbp_invariance(v, cfg) else {
          y <- qbp_transform(v, "uniform")
          if (part == 6L) y <- qbp_contaminate(y, case$epsilon, cfg$CONTAM_MAGNITUDE, cfg$CONTAM_JITTER)
          y <- resolve(y, "observed_block")
          levels <- if (part == 3L) cfg$MIXED_LEVELS else cfg$LEVELS
          list(tests = qbp_permutation_tests(y, qbp_context(n, cfg$H, levels),
                                            cfg$B_PERMUTATION, ordered6 = part == 3L))
        }
    }
  }, error = function(e) list(error = conditionMessage(e)))
  out$status <- if (is.null(out$error)) "ok" else "error"
  if (length(tie_records)) out$numerical_ties <- do.call(rbind, tie_records)
  out$case <- case; out$replication <- replication
  out$elapsed_seconds <- unname(proc.time()[["elapsed"]] - start)
  out
}
