qbp_surface <- function(kappa, ctx, tuple, omega = seq(-pi, pi, length.out = 65L),
                        weights = rep(1, nrow(ctx$lags))) {
  cf <- qbp_coefficients(kappa, ctx, tuple, weights)
  f <- as.matrix(expand.grid(w1 = omega, w2 = omega))
  val <- as.numeric(cf$coefficient) %*%
    exp(-1i * (outer(cf$h, f[, 1L]) + outer(cf$k, f[, 2L]))) / (2*pi)^2
  matrix(as.vector(val), length(omega), length(omega))
}

qbp_example_spectrum <- function(directory, n = 8192L, theta = .9,
                                 model = "even", tuple = c(.25, .25, .25), seed = 20260924L) {
  set.seed(seed)
  v <- qbp_block_uniform(n, theta, model)
  levels <- sort(unique(c(.25, .5, .75, tuple)))
  ctx <- qbp_context(n, 3L, levels)
  kr <- qbp_moments(qbp_rank_data(v, ctx)$category, ctx)
  ko <- qbp_moments(findInterval(v, levels, left.open = TRUE), ctx)
  truth <- qbp_truth(ctx, theta, model)
  omega <- seq(-pi, pi, length.out = 65L)
  surfaces <- list(Population = qbp_surface(truth, ctx, tuple, omega),
                   Rank = qbp_surface(kr, ctx, tuple, omega),
                   Oracle = qbp_surface(ko, ctx, tuple, omega))
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
  zlim <- range(unlist(lapply(surfaces, Re)))
  if (diff(zlim) == 0) zlim <- zlim + c(-1, 1) * .Machine$double.eps
  png(file.path(directory, "example_real_bispectrum.png"), width = 2400, height = 850, res = 180)
  tryCatch({
    par(mfrow = c(1, 3), mar = c(4, 4, 2.5, 1), las = 1)
    for (name in names(surfaces)) {
      image(omega, omega, Re(surfaces[[name]]), col = hcl.colors(60, "Blue-Red 3"), zlim = zlim,
            xlab = expression(omega[1]), ylab = expression(omega[2]), main = name, useRaster = TRUE)
      contour(omega, omega, Re(surfaces[[name]]), add = TRUE, drawlabels = FALSE,
              col = adjustcolor("black", .35))
    }
  }, finally = dev.off())
  saveRDS(list(n = n, theta = theta, model = model, tuple = tuple, omega = omega,
               surfaces = surfaces, seed = seed), file.path(directory, "example_spectrum.rds"))
  invisible(surfaces)
}
